class Table {
    constructor() {
        this.tableParentID = "table_container";     // the modal body - should be able to use this for them all.
        this.x_variable = [];
        this.x_variableDesc = null;
        this.y_variable = [];
        this.y_variableDesc = null;
        this.chartData = null;
        this.labelFormat = d3.format(',.2f');
    }

    
    buildChart(inDataObj, x, y) {
        var headers = JSON.parse(JSON.stringify(yearDesc));
        headers.unshift("");

        var tuition = d3.nest()
            .key(function (d) {
                return d.year;
            })
            .rollup(function (v) {
                var orig_t =  d3.sum(v, function (d) { return d.original_total_tuition; });
                var new_t = d3.sum(v, function (d) { return d.new_total_tuition; });
                var diff_t = new_t - orig_t;
                return {
                    original_tuition: orig_t,
                    new_tuition: new_t,
                    difference: diff_t
                };
            }).entries(inDataObj.data);

        var table_container = document.getElementById(this.tableParentID);
        var table = document.createElement("table");
        table.setAttribute("class", "table");

        var tableheader = document.createElement("thead");
        tableheader.setAttribute("class", "thead-dark");
        var tableheader_row = document.createElement("tr");
        for(var i=0; i<headers.length; i++) {
            var tableheader_col = document.createElement("th");
            tableheader_col.setAttribute("scope", "col");
            tableheader_col.setAttribute("class", "text-right");
            tableheader_col.innerHTML = headers[i];
            tableheader_row.appendChild(tableheader_col);
        }
        tableheader.appendChild(tableheader_row);
        table.appendChild(tableheader);

        var table_body = document.createElement("tbody");

        for(var i=0; i<3; i++) {
            var table_row = document.createElement("tr");
            table_row.setAttribute("scope", "row");

            for(var j=0; j<=tuition.length; j++){
                if (j==0) {
                    // row headers
                    var table_data = document.createElement("th");
                    if (i==0) 
                        table_data.innerHTML = "New Tuition";
                    else if (i==1) 
                        table_data.innerHTML = "Original Tuition";
                    else if (i==2) 
                        table_data.innerHTML = "Difference";
                    table_row.appendChild(table_data);
                }
                else {
                    var table_data = document.createElement("td");
                    table_data.setAttribute("class", "text-right");
                    var value;
                    if (i==0)
                        value = tuition[j-1].value.new_tuition;
                    else if (i==1) 
                        value = tuition[j-1].value.original_tuition;
                    else if (i==2) 
                        value = tuition[j-1].value.difference;

                    if (value < 0 && i==2)
                        table_data.setAttribute("class", "text-right text-danger");
                    else if (value > 0 && i==2)
                        table_data.setAttribute("class", "text-right text-success");

                        /*
                    if (i==0) {
                        table_data.innerHTML ="$" + this.labelFormat(tuition[j-1].value.new_tuition);
                        if (tuition[j-1].value.new_tuition<0)
                            table_data.setAttribute("class", "text-right ");
                    }
                    else if (i==1) 
                        table_data.innerHTML = "$" + this.labelFormat(tuition[j-1].value.original_tuition);
                    else if (i==2) 
                        table_data.innerHTML = this.labelFormat(tuition[j-1].value.difference);
                    */

                    table_data.innerHTML ="$" + this.labelFormat(value);

                    table_row.appendChild(table_data);
                }
            }
            table_body.appendChild(table_row);
        }
        table.appendChild(table_body);

        // Get the table container, remove all child nodes, then appended the new to it.
        if (table_container.firstChild !== null) {
            while (table_container.firstChild) {
                table_container.removeChild(table_container.firstChild);
            }
        }
        table_container.appendChild(table);
    }
}