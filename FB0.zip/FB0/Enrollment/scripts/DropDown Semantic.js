// Requires D3.V4


function DropDown(htmlObjID, dropDownTitle) {
    this.htmlObjID = htmlObjID;   /* This is the html object where the expanded button menu will live. */
    this.var = null;  
    this.values = null; 
    this.buttonSize = 120;
    this.scroll = false;
    this.maxScroll = "28rem";
    this.dropDownTitle = dropDownTitle;
    this.numberItemsChecked = 0;
    this.dropDownClass = null;
}

DropDown.prototype.insertDropdown = function (dataSet, variable, dropDownClass, orderOption) {
    this.var = variable;
    this.values = d3.map(dataSet, function(d) {return d[variable];}).keys();
    this.dropDownClass = dropDownClass;

    // Reverse the order. 
    // 2 - reverses the list alphabetically.
    // 1 - puts it in ascending order.
    // null or another number - leaves it as is.
    if (orderOption === 1)
        this.values.sort();
    else if (orderOption === 2)
        this.values.reverse();
    /*
    if (orderOption === 1)
        this.values.sort(function(x, y) {
                return d3.ascending(x.index, y.index);
        });
    else if (orderOption === 2)
        this.values.reverse(function(x, y) {
                return d3.ascending(x.index, y.index);
        });
    */

    // This is the main container for the drop down.
    var mainContainer = document.createElement("div");
    if (this.scroll == false) { 
        mainContainer.setAttribute("class", "ui dropdown " + this.dropDownClass +  " basic right labeled  icon button" + " dropdown_" + this.var);
        mainContainer.setAttribute("style", "width:" + this.buttonSize + "px;");
    }
    else {
        mainContainer.setAttribute("class", "ui scrolling dropdown " + this.dropDownClass +  " basic right labeled  icon button" + " dropdown_" + this.var);
        //mainContainer.setAttribute("style", "width:" + this.buttonSize + "px; max-height:" + this.maxScroll + ";");
        // does not work
    }
    mainContainer.setAttribute("id", "dropdown_" + this.var);
    
    //mainContainer.setAttribute("style", "margin: 2px 2px 2px 2px;padding: 3px 3px 3px 3px; background-color: #F8F9F9; border-radius: 8px; border: 2px solid #B1728D; display: inline-block; width:700px");
    //document.getElementById("controlPanel").appendChild(div);

    // This is the icon for the drop down.
    var icon = document.createElement("i");
    icon.setAttribute("class", "dropdown icon");
    //document.getElementById("dropdown_" + this.var).appendChild(icon);
    mainContainer.appendChild(icon);

    // This is the title for the drop down (what the user sees initially).
    var title = document.createElement("span");
    title.setAttribute("class", "ui tiny header");
    title.innerHTML = this.dropDownTitle;
    //document.getElementById("dropdown_" + this.var).appendChild(title);
    mainContainer.appendChild(title);

    // This is will hold the selectable items.
    var selectContainer = document.createElement("div");
    selectContainer.setAttribute("class", "menu");
    selectContainer.setAttribute("id", "sub_dropdown_" + this.var);
    selectContainer.style.maxHeight = "28rem";
    mainContainer.appendChild(selectContainer);

    // Loop through all values inserting them into the selectContainer.
    for(var i = 0; i<this.values.length; i++) {
        if (i==0) {
            var selection = document.createElement("div");
            selection.setAttribute("class", "ui item checkbox");
            selection.setAttribute("data-value", "all");
            selection.innerHTML = '<input type="checkbox" name="all" checked><label>' + "All" + '</label>';
            selection.addEventListener("change", function () {
                // see if it was clicked on or off.
                var position = this.childNodes[0].checked;
                //console.log("All is click on = " + position);
                // if position is false then remove the check box from all elements in the dropdown.
                // if position is true then check all the boxes for elements in the dropdown.
                var sybilings = this.parentNode.childNodes;
                for(var i=0; i<sybilings.length; i++) {
                    if (position == false) {
                        sybilings[i].childNodes[0].checked=false;
                        this.numberItemsChecked--;
                    }
                    else {
                        sybilings[i].childNodes[0].checked=true;
                        this.numberItemsChecked++;
                    }
                }
            });
            selectContainer.appendChild(selection);
        }
        var selection = document.createElement("div");
        selection.setAttribute("class", "ui item checkbox");
        selection.setAttribute("id", "dropdown_item_" + this.var + "_" + this.values[i]);
        //selection.setAttribute("data-value", this.values[i]);
        selection.innerHTML = '<input type="checkbox" name="item' + i + '" checked><label>' + this.values[i] + '</label>';
        selection.addEventListener("change", function () {
                // if all was checked and the one we clicked on is now not checked then remove the check from all.
                var position = this.childNodes[0].checked;
                var all_node = this.parentNode.childNodes[0].childNodes[0].checked;
                if (position == false && all_node == true) { 
                    this.parentNode.childNodes[0].childNodes[0].checked = false;
                    return;
                }

                // now look to see if everything is checked except all.
                // if so then we must check all as well.
                var sybilings = this.parentNode.children;
                //var numberChecked = 0;
                var total = sybilings.length;
                for (var i=1; i<total; i++) {
                    // all node is not check and another one is also not checked, so this is ok.
                    if (all_node == false && sybilings[i].childNodes[0].checked == false) 
                        return; 
                }
                // if we ran through the above loop and it did not return then all needs to be checked.
                this.parentNode.childNodes[0].childNodes[0].checked = true;
            });
        selectContainer.appendChild(selection);
    }

    document.getElementById(this.htmlObjID).appendChild(mainContainer);
    

    $('.ui.dropdown.' + this.dropDownClass).dropdown({
        action: 'nothing',
        onHide: function () {
                console.log(this.id  + " is hidden now.");
                var filtersBefore = copyObject(filteredData.filters);

                // Here is where we need to add the filters to filterObj.
                // If all is checked then nothing is added, but we will need to remove any filters remaining from this selection list.
                // If nothing is checked then nothing is added but we may want to indicated there is nothing checked in this filter some how.
                var selections = this.childNodes[2].childNodes;
                var all_node_checked = selections[0].childNodes[0].checked;
                var variable = this.id.substring(9);

                // Count the number of checks and unchecks in the dropdown.
                var num_Checked = 0;
                for (var i=1; i<selections.length; i++) {
                    if (selections[i].childNodes[0].checked == true)
                        num_Checked++;
                }
                var num_NotChecked = selections.length - num_Checked - 1;
                if(num_Checked > 0 && num_NotChecked != 0) {
                    // Something is checked other than all.
                    this.className = this.className.replace("red", "grey");
                    this.className = this.className.replace("basic", "grey");
                }
                else if(num_Checked == 0 ) {
                    // Nothing is checked.
                    this.className = this.className.replace("grey", "basic");
                    this.className = this.className.replace("basic", "red");
                }
                else if(num_NotChecked == 0 ) {
                    // All are checked in this dropdown.
                    this.className = this.className.replace("red", "grey");
                    this.className = this.className.replace("grey", "basic");
                }
                

                // See if nothing is checked in this dropdown. 
                /*
                var somethingIsChecked = false;
                for (var i=1; i<selections.length; i++) {
                    if (selections[i].childNodes[0].checked == true) {
                        somethingIsChecked = true;
                        break; // break the loop because something is checked.
                    }
                }
                if (somethingIsChecked == false) {
                    // Nothing is checked.
                    this.childNodes[1].style.textDecoration = "line-through";
                    this.childNodes[1].style.color = "red";
                }
                else {
                    // Something is checked in this dropdown.
                    this.childNodes[1].style.textDecoration = "";
                    this.childNodes[1].style.color = "";
                }
                */

                var emptyDropDowns = anyMissingDropDownChecks();
                if (emptyDropDowns > 0) {
                    barChart.drawChart([]);
                    return;
                }
                /*
                // See if any of the dropdowns don't have checks.
                var otherDropDownIsChecked = false;
                var syblings = this.parentNode.childNodes;
                for (var i = 0; i< syblings.length; i++) {
                    if (syblings[i].nodeName == "DIV") {
                        var className = syblings[i].className;
                        var red_location = className.indexOf("red");
                        if (red_location >= 0) {
                            otherDropDownIsChecked = true;
                            break;
                        }
                    }
                }
                if (otherDropDownIsChecked == true) {
                    // Reset data so nothing shows in graph because one or more dropdowns don't have values.
                    barChart.drawChart([]);
                    return;
                }
                */
                
                // -- Below is not very efficient code.... :( 
                for (var i=1; i<selections.length; i++) {
                    var value = selections[i].innerText.trim();
                    // remove existing filters.
                    filteredData.removeFilter(variable, value);
                    // add filters that are selected given all is not checked.
                    if (all_node_checked == false && selections[i].childNodes[0].checked == true) 
                        filteredData.insertFilter(variable, value); 
                }   

                // if nothing has changed then just return.
                var filtersNow = copyObject(filteredData.filters);
                if (compareArrays(filtersBefore, filtersNow) && barChart.chartData.length != 0)
                    return;

                filteredData.summarizeData();
                barChart.drawChart(filteredData.data); 

                
        },
        onShow: function () {
                console.log(this.id + " is showing.");
        }
    });
    $('.ui.checkbox').checkbox();
}