const studentType=[
'Continuing',
'EKU Dual Credit',
'Grad Probationary Admission',
'High School Special',
'New First Time Freshman',
'New First Time Grad Applicant',
'New First Time Transfer',
'Non Degree',
'Other',
'Returning',
'Visiting'
];
