// inlineBlock = d-inline-block to make dropdowns on the same line.

function DropDownValue(){
    this.value = null;
    this.show = true;
}


function DropDown(htmlObjID, dropDownTitle) {
    //this.DataObject = dataObject;
    this.htmlObjID = htmlObjID;   /* This is the html object where the expanded button menu will live. */
    this.var = null;  
    this.values = [];
    this.buttonSize = 120;
    this.scroll = false;
    this.maxScroll = "28rem";
    this.dropDownTitle = dropDownTitle;
    this.numberItemsChecked = 0;
    this.dropDownClass = null;
    this.checkedItems = []; // assumed all are checked if this is blank.
    this.showOnlyRelaventValues = true; // only show values that show up in selected filters.
}

DropDown.prototype.insertDropdown = function (dataSet, variable, dropDownClass, orderOption, descriptionArray, inlineBlock, menuWidth) {
    this.var = variable;
    // values needs to be numeric. 
    var values = d3.map(dataSet, function(d) {return d[variable];}).keys();

    //for (var i=0; i<this.values.length; i++)
    //    this.values[i] = +this.values[i];
    this.dropDownClass = dropDownClass;

    // Reverse the order. 
    // 2 - reverses the list alphabetically.
    // 1 - puts it in ascending order.
    // null or another number - leaves it as is.
    if (orderOption === 1)
        values.sort(function (a,b) { return a-b});
    else if (orderOption === 2)
        values.reverse(function (a,b) { return a-b});

    // create the values object. 
    for (var i=0; i<values.length; i++) {
        this.values[i] = new DropDownValue();
        this.values[i].value = values[i];
    }

    // This is the main container for the drop down.
    var mainContainer = document.createElement("div");
    mainContainer.setAttribute("id", "dropdown_" + this.dropDownClass);
    mainContainer.setAttribute("class", "p-1 dropdown " + this.dropDownClass  + " dropdown_" + this.var + " " + inlineBlock);
  

    // Create the button for the dropdown. 
    var button = document.createElement("button");
    button.setAttribute("class", "btn btn-primary dropdown-toggle");
    button.setAttribute("data-toggle", "dropdown");
    button.setAttribute("style",  "min-width: " + "10rem;");
    button.innerHTML = this.dropDownTitle;
    mainContainer.appendChild(button);

    // Create the div to hold the menu. 
    var menuContainer = document.createElement("div");
    menuContainer.setAttribute("class", "dropdown-menu");
    menuContainer.setAttribute("style",  "min-width: " + menuWidth + "rem; max-height: 500px; overflow-y:auto;");

    // Create the checkboxes within the menu.
    for(var i = 0; i<this.values.length; i++) {

        // Create the all check box on the first run. 
        if (i==0){
            var divForm = document.createElement("div");
            divForm.setAttribute("id", "checkboxlabel_" +  this.dropDownClass ); 
            divForm.setAttribute("class", "form-check ml-2");

            var label = document.createElement("label");
            label.setAttribute("class", "form-check-label font-weight-bold text-uppercase"); 

            var input = document.createElement("input");
            input.setAttribute("id", "checkbox_all_" +  this.dropDownClass ); 
            input.setAttribute("type", "checkbox");
            input.setAttribute("class", "form-check-input genDropdownCheck");
            input.setAttribute("checked", "checked");
            input.setAttribute("value", this.var + ":All");
            label.appendChild(input);

            var text = document.createTextNode("All");
            label.appendChild(text);

            divForm.appendChild(label);
            menuContainer.appendChild(divForm);
        }

        var divForm = document.createElement("div");
        divForm.setAttribute("id", "checkboxlabel_" +  this.dropDownClass ); 
        divForm.setAttribute("class", "form-check ml-2");

        // Honestly when this is first created they all should be true. 
        if (this.values[i].show === false) {
            divForm.setAttribute("class", "form-check ml-2 d-none");
        }

        var label = document.createElement("label");
        label.setAttribute("class", "form-check-label");       

        var input = document.createElement("input");
        input.setAttribute("id", "checkbox_" +  this.dropDownClass); 
        input.setAttribute("type", "checkbox");
        input.setAttribute("class", "form-check-input genDropdownCheck checkbox_" +  this.dropDownClass);
        input.setAttribute("checked", "checked");
        input.setAttribute("value", this.var + ":" + this.values[i].value);
        label.appendChild(input);

        var text = document.createTextNode( descriptionArray[this.values[i].value]);
        label.appendChild(text);

        divForm.appendChild(label);
        menuContainer.appendChild(divForm);
    }
    mainContainer.appendChild(menuContainer);


    document.getElementById(this.htmlObjID).appendChild(mainContainer);

    $("#dropdown_" + this.dropDownClass).on('show.bs.dropdown', function () { 
        // This is so we can't click the button with an open drop down.
        //var button = $("#goButton");
        //button[0].disabled = true;
    });

    $("#dropdown_" + this.dropDownClass).on('hide.bs.dropdown', function () {
        var unchecked_count = 0;
        var node = this;
        var nodeList = node.childNodes[1].childNodes;
        var variable = "";
        for(var i=0; i<nodeList.length; i++){
            var element=nodeList[i].childNodes[0].childNodes[0];

            // variable name and value should be split by :
            var name_value = element.value.split(':');
            var varName = name_value[0];
            var value = name_value[1];

            if (i==0) {
                // on the first pass remove all filters for this variable.
                DataObject.removeAllFilters(varName); // remove all filters for this variable.
                variable = varName;
            }

            if(element.checked == true) {
                if (value === "All") {
                    break;
                }
                else {
                    // insert the filter. 
                    DataObject.insertFilterObj(varName, value);
                }
            }
            else {
                unchecked_count++;
            }
        }

        // If nothing is checked change the button color. 
        var button = node.childNodes[0];
        if (unchecked_count === nodeList.length) {
            button.className = "btn btn-danger dropdown-toggle";
        }
        else {
            button.className = "btn btn-primary dropdown-toggle";
        }
        
        // Apply the filters.
        DataObject.applyFilters(); // global object - applies all filters to the data. 
        // loop through each dropdown for relevant values - if unchecked then hide it.
        var dropDownCheckBoxes = $(".genDropdownCheck");
        for(var i =0; i<dropDownCheckBoxes.length; i++) {
            var node = dropDownCheckBoxes[i];
            // variable name and value should be split by :
            var name_value = node.value.split(':');
            var varName = name_value[0];
            var value = name_value[1];
            if (node.checked != true && value !== "All") {
                node.parentNode.hidden = true;
            }

        }

        // Hide the dropdown non-relevant values.
        var values = d3.map(DataObject.data, function(d) {return d[variable];}).keys();
        for(var i=0; i<nodeList.length; i++){
            var element=nodeList[i].childNodes[0].childNodes[0];

            // variable name and value should be split by :
            var name_value = element.value.split(':');
            var varName = name_value[0];
            var value = name_value[1];

            var found = false;
            for (var j=0; j<values.length; j++) {
                if (values[j] == value || value === 'All') {
                    found = true;
                    var node = nodeList[i];
                    node.hidden = false;
                    //node.childNodes[0].control.checked = true; // so all gets checked. 
                    break;
                }
            }
            if (found == false) {
                // hide it.
                var node = nodeList[i];
                node.hidden = true;
            }
        }
      });


    // Handle the All check box.
    $("#checkbox_all_" + this.dropDownClass).click(function () {
        var node = this;
        var nodeList = node.parentNode.parentNode.parentNode.childNodes;
        for(var i=0; i<nodeList.length; i++){
            var element=nodeList[i].childNodes[0].childNodes[0];
            element.checked = node.checked;
        }
      });

    // Handle the other check boxes, basically we just need to remove the all check box.
    $(".form-check-input.checkbox_" +  this.dropDownClass).click(function () {
        var node = this;
        var allNode = node.parentNode.parentNode.parentNode.childNodes[0].childNodes[0].childNodes[0];
        if (node.checked == false) {
            // remove the all check box. 
            allNode.checked = false;
        }
        else {
            // The node is checked so make everything else is checked. 
            // Start at 1, the first element is the all node.
            var nodeList = node.parentNode.parentNode.parentNode.childNodes;
            for(var i=1; i<nodeList.length; i++){
                var element=nodeList[i].childNodes[0].childNodes[0];
                // variable name and value should be split by :
                var name_value = element.value.split(':');
                var varName = name_value[0];
                var value = name_value[1];
                if (element.checked == false) {
                    // if we find another not check then return.
                    return;
                }
            }
            // If we have gone through the loop and did not find anything check then check the all node.
            allNode.checked = true;
        }

      });

    /*
    $('.dropdown.' + this.dropDownClass).dropdown({
        action: 'nothing',
        onHide: function () {
                console.log(this.id  + " is hidden now.");
                var filtersBefore = copyObject(filteredData.filters);

                // Here is where we need to add the filters to filterObj.
                // If all is checked then nothing is added, but we will need to remove any filters remaining from this selection list.
                // If nothing is checked then nothing is added but we may want to indicated there is nothing checked in this filter some how.
                var selections = this.childNodes[2].childNodes;
                var all_node_checked = selections[0].childNodes[0].checked;
                var variable = this.id.substring(9);

                // Count the number of checks and unchecks in the dropdown.
                var num_Checked = 0;
                for (var i=1; i<selections.length; i++) {
                    if (selections[i].childNodes[0].checked == true)
                        num_Checked++;
                }
                var num_NotChecked = selections.length - num_Checked - 1;
                if(num_Checked > 0 && num_NotChecked != 0) {
                    // Something is checked other than all.
                    this.className = this.className.replace("red", "grey");
                    this.className = this.className.replace("basic", "grey");
                }
                else if(num_Checked == 0 ) {
                    // Nothing is checked.
                    this.className = this.className.replace("grey", "basic");
                    this.className = this.className.replace("basic", "red");
                }
                else if(num_NotChecked == 0 ) {
                    // All are checked in this dropdown.
                    this.className = this.className.replace("red", "grey");
                    this.className = this.className.replace("grey", "basic");
                }
               

                // See if nothing is checked in this dropdown. 
                /*
                var somethingIsChecked = false;
                for (var i=1; i<selections.length; i++) {
                    if (selections[i].childNodes[0].checked == true) {
                        somethingIsChecked = true;
                        break; // break the loop because something is checked.
                    }
                }
                if (somethingIsChecked == false) {
                    // Nothing is checked.
                    this.childNodes[1].style.textDecoration = "line-through";
                    this.childNodes[1].style.color = "red";
                }
                else {
                    // Something is checked in this dropdown.
                    this.childNodes[1].style.textDecoration = "";
                    this.childNodes[1].style.color = "";
                }
                */
/*
                var emptyDropDowns = anyMissingDropDownChecks();
                if (emptyDropDowns > 0) {
                    barChart.drawChart([]);
                    return;
                }
                /*
                // See if any of the dropdowns don't have checks.
                var otherDropDownIsChecked = false;
                var syblings = this.parentNode.childNodes;
                for (var i = 0; i< syblings.length; i++) {
                    if (syblings[i].nodeName == "DIV") {
                        var className = syblings[i].className;
                        var red_location = className.indexOf("red");
                        if (red_location >= 0) {
                            otherDropDownIsChecked = true;
                            break;
                        }
                    }
                }
                if (otherDropDownIsChecked == true) {
                    // Reset data so nothing shows in graph because one or more dropdowns don't have values.
                    barChart.drawChart([]);
                    return;
                }
                */
    /*            
                // -- Below is not very efficient code.... :( 
                for (var i=1; i<selections.length; i++) {
                    var value = selections[i].innerText.trim();
                    // remove existing filters.
                    filteredData.removeFilter(variable, value);
                    // add filters that are selected given all is not checked.
                    if (all_node_checked == false && selections[i].childNodes[0].checked == true) 
                        filteredData.insertFilter(variable, value); 
                }   

                // if nothing has changed then just return.
                var filtersNow = copyObject(filteredData.filters);
                if (compareArrays(filtersBefore, filtersNow) && barChart.chartData.length != 0)
                    return;

                filteredData.summarizeData();
                barChart.drawChart(filteredData.data); 

                
        },
        onShow: function () {
                console.log(this.id + " is showing.");
        }
    });
    $('.ui.checkbox').checkbox();
    */
}