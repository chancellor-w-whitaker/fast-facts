

function FilterObj() {  
    this.data = d3Data;     // initially set to the global variable d3Data.
    this.filters = [];      // initially set to empty array.
}

FilterObj.prototype.summarizeData = function () {
    // multiple filters from the same variable -- how to handle that?
    // If multiple filters are selected from the same variable then we must include them both.

    // Summarize the data based on active filters. 
    var selectedFilters = this.filters;
    var distinctFilterVars = d3.map(this.filters, function(d) {
            return d.varName;
            })
            .keys();
    var temp_data = d3Data; // initially set to the global variable d3Data.
    var newFilterData = [];
    for (var i=0; i<temp_data.length; i++) {
        var matchCount = 0;
        for (var j=0; j<selectedFilters.length; j++){
            var variable = selectedFilters[j].varName;
            var value = selectedFilters[j].varValue;
            if (temp_data[i][variable] == value)
                matchCount++;
        }
        if (matchCount == distinctFilterVars.length)
            newFilterData.push(temp_data[i]);
    }
    this.data=newFilterData;

    this.filtersApplied();
}

FilterObj.prototype.getEmpty = function () {
    return [];    
}

FilterObj.prototype.insertFilter = function (varName, varValue) {
    // make sure it does not already exist. 
    var object = {"varName":varName, "varValue":varValue};

    for (var i=0; i<this.filters.length; i++){
        if (JSON.stringify(object) === JSON.stringify(this.filters[i])) {
            return; // it already exists so return. 
        }
    }
    this.filters.push(object);
    
    //this.summarizeData();
    
}

FilterObj.prototype.removeFilter = function (varName, varValue) {
    var newFilterArray = [];
    var object = {"varName":varName, "varValue":varValue};

    // Loop through our current filters. 
    // If the filter is not equal to the one we are removing then push it to the new filter list.
    for (var i=0; i<this.filters.length; i++){
        if (JSON.stringify(object) !== JSON.stringify(this.filters[i]))
            newFilterArray.push(this.filters[i]);
    }

    // if we looped through all the filters and nothing changed (they all were pushed to new array) then just exit this function.
    if (this.filters.length == newFilterArray.length)
        return;

    this.filters = newFilterArray;
    //this.summarizeData();
    //this.filtersApplied();
}

FilterObj.prototype.clearAllFilters = function () {
    this.data = d3Data;     // reset the dataset.
    this.filters = [];      // clear all filters from filter array.

    // Clear all ButtonGroup buttons that are active = grey. 
    // Can't use for loop because buttonGroups gets modified as we loop.
    var buttonGroups = document.getElementsByClassName("button grey");
    while(buttonGroups.length > 0) {
        buttonGroups[0].className = buttonGroups[0].className.replace("grey", "basic");
    }

    // Will need to recheck all dropdown boxes.
    var dropDownContainers = document.getElementsByClassName("ui dropdown");
    for(var i = 0; i<dropDownContainers.length; i++) {
        var dropDownElements = dropDownContainers[i].childNodes[2].childNodes;
        for(var j=0; j<dropDownElements.length; j++) {
            var element = dropDownElements[j].childNodes[0];
            if (element.checked == false) 
                element.checked = true;
        }
    }
}

FilterObj.prototype.filtersAppliedButtons = function () {
/*
    From Drupal the page height needs to be static for it to work the way I want. 
    I can't extend the page dynamically which means I should not add the filtersApplied buttons.
        - Instead just update the look of the dropdown header.
*/


    /*
    var div = document.createElement("div");
        div.setAttribute("class", "filtersApplied");
        div.setAttribute("id", "filtersApplied");
        div.setAttribute("style", "margin: 2px 2px 2px 2px;padding: 3px 3px 3px 3px; background-color: #F8F9F9; border-radius: 8px; border: 2px solid #B1728D; display: inline-block; width:740px");
        div.innerHTML = '<div style="font-weight: bold;margin: 5px;">Selected Filters</div>';
        document.getElementById("controlPanel").appendChild(div);
        for(var i=0; i<this.filters.length; i++) {
            var button = document.createElement("a");
            button.setAttribute("class", "ui button green"); 
            button.setAttribute("id", "appliedFilter_" + this.filters[i].varName + "_"  + this.filters[i].varValue);
            button.setAttribute('style', 'margin: 2px; padding: 8px 6px 8px 6px;');
            button.innerHTML =  this.filters[i].varValue + ' <i class="remove icon"></i>';
            button.addEventListener("click", function () {
                // when filter button is clicked removed it.
                // I need the variable and the value.
                var id_breakdown = this.id.split("_");
                var varName = id_breakdown[1];
                var varVal = id_breakdown[2];
                filteredData.removeFilter(varName, varVal);     // filteredData is global
                filteredData.summarizeData();
                barChart.drawChart(filteredData.data);          // barChart is global (redraw the chart with removed filter.)

                // Now I need to unselect the filter from the button group.
                var selectionID = "select_" + varName;   // This will be the group id.
                var buttonGroup = document.getElementById(selectionID); 
                if(buttonGroup !== null) {
                    var button = buttonGroup.getElementsByClassName("ui button grey");  // is an array so loop through it. (may need work later.)
                    button[0].className = button[0].className.replace("grey", "basic");
                }

                // Now deal with dropdown.
                selectionID = "dropdown_item_" + varName + "_" + varVal;
                var dropDown = document.getElementById(selectionID);
                if (dropDown !== null) {
                    // uncheck it the one that we clicked on.
                    dropDown.childNodes[0].checked = false;
                    // everything may be unchecked at this point. If so we need to check everything.

                    var syblings = dropDown.parentNode.childNodes;
                    var checkedCount = 0;
                    // see how many are checked
                    for (var j=0; j<syblings.length; j++) {
                        if (syblings[j].childNodes[0].checked == true)
                            checkedCount++;
                    }
                    // if it is zero then check them all. 
                    if (checkedCount == 0) {
                        for (var j=0; j<syblings.length; j++) {
                            syblings[j].childNodes[0].checked = true;
                        }
                    }
                }
            });
            document.getElementById("filtersApplied").appendChild(button);
            
            
        }
        //window.parent.document.getElementById('iFrameDrupal').height = '500px';

        // create a read button to clear all filters.
        var button = document.createElement("a"); 
        button.setAttribute("class", "ui button red"); 
        button.setAttribute("id", "clearAllFilters");
        button.setAttribute('style', 'margin: 2px; padding: 8px 6px 8px 6px;');
        button.innerHTML =  '<i class="backward icon"></i>' + "Clear All Filters";
        button.addEventListener("click", function () {
                filteredData.clearAllFilters();                 // filteredData is global
                filteredData.filtersApplied();
                barChart.drawChart(filteredData.data);          // barChart is global (redraw the chart with removed filter.)
        });
        document.getElementById("filtersApplied").appendChild(button);
        */
}

FilterObj.prototype.filtersApplied = function () {
    // Get the data values.
    var values = d3.map(this.filters, function(d) {
            console.log("5");
            return d.varValue;
            })
            .keys();

    // See if the filtersApplied div exists.
    var container;
    var filtersApplied = document.getElementById('filtersApplied');
    // filtersApplied does not exist but we do have filters.
    if (filtersApplied === null && values.length > 0) {
        // Create the buttons.
        this.filtersAppliedButtons();
    }
    // filtersApplied does exist but we do not have filters.
    else if (filtersApplied !== null && values.length == 0) {
        filtersApplied.parentNode.removeChild(filtersApplied);
    }
    // filtersApplied does exist and we do have filters.
    else if (filtersApplied !== null && values.length > 0) {
        filtersApplied.parentNode.removeChild(filtersApplied);
        this.filtersAppliedButtons();
    }
}