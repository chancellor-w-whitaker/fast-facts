/*
Adjustments can be made to any of these methods outside of this file.
This is just the standard default operation of a single column bar chart. 

https://bl.ocks.org/syncopika/f1c9036b0deb058454f825238a95b6be
This webpage was vital in helping me update and existing svg.
*/

/*
Add responsive width to the chart - this will shrink the columns with the screen descreases. 
Add this code to the main page.
barChart is a global variable that you create in the main page.
    function screenUpdateChart() {  
      barChart.updateChart();
    }
    window.addEventListener("resize", screenUpdateChart);
*/ 
function MultiLineChart(htmlObjID, xVariable) {
    this.htmlObjID = "#" + htmlObjID;   /* This is the html object where the chart will live. */
    this.htmlChartID = htmlObjID + "_multiLine";
    this.zVar = null  /* String -- Categorical column - This is what the lines are divided into. */
    this.xVar = xVariable;                      /* String - Categorical column in data */   
    this.yVars = [];                      /* array of variable, variable_desc pairs. */
    this.denominator = null;              /* this is blank if we just want sums. */
    this.height = 400;
    this.margins = { top: 30, right: 20, bottom: 20, left: 45 };
    this.labelFormat = d3.format(',.0f');
 
    /* --- These properties should not be modified and are set in methods ---  */
    this.minMaxValues = {};     // For y domain. 
    this.dataIsSet = false;
    this.chartData = null;
    this.svg = null;
    this.g = null;
    this.x = null;
    this.y = null;
    this.z = null;
}

// Push a y Variable column into the yVar array. 
MultiLineChart.prototype.insertYVariable = function (in_variable, in_variable_desc) {
    var yVar = {variable:in_variable, variable_desc:in_variable_desc};
    this.yVars.push(yVar);
}

MultiLineChart.prototype.keepRequiredCols = function () {
    // 
    var newData = [];
    for(var i=0; i<this.chartData.length; i++) {
        var newObj = {};

        // xVar should always be present. 
        newObj[this.xVar] = this.chartData[i][this.xVar];

        // zVar may or may not be present. 
        if (this.zVar !== null) {
            newObj[this.zVar] = this.chartData[i][this.zVar];
        }

        // denominator may or may not be present. 
        if (this.denominator !== null) {
            newObj[this.denominator] = this.chartData[i][this.denominator];
        }

        // yVars should always have at least 1 value. 
        for(var j=0; j<this.yVars.length; j++) {
            newObj[this.yVars[j].variable] = this.chartData[i][this.yVars[j].variable];
            //console.log(this.chartData[i][this.yVars[j].variable]);
        }
        newData.push(newObj);
    }
    return newData;
}

MultiLineChart.prototype.getXDomain = function () {
    // z domain is always the top nodes
    // x domain is the sub nodes of that.
    var xDom = [];
    for(var i=0; i<this.chartData.length; i++) {
        this.chartData[i].values.map(function (d) {
            if (xDom.length == 0) 
                xDom.push(d.key);
            else {
                var loc = xDom.indexOf(d.key);
                if(loc == -1)
                    xDom.push(d.key);
            }
        });     
    }
    return xDom.sort();
}

MultiLineChart.prototype.rollUpData = function () {
    if (this.dataIsSet == true)
        return;

    var xVar = this.xVar;
    var yVars = this.yVars;
    var zVar = this.zVar;
    var denominator = this.denominator;
    var minMaxValues = {};

    this.chartData = d3.nest()
        .key(function (d) { 
            if (zVar==null)
                return "Total";
            return d[zVar]; 
        })
        .key(function (d) { return d[xVar]; })
        .rollup(function (v) { 
            var dat={};
            if(denominator != null)
                dat.total = d3.sum(v, function (d) { return d[denominator]; });
            for (var i=0; i<yVars.length; i++) {
                if (denominator == null) { 
                    dat[yVars[i].variable] = d3.sum(v, function (d) { return d[yVars[i].variable]; });
                    if (isNaN(minMaxValues["min"]))
                        minMaxValues["min"] = dat[yVars[i].variable];
                    if (isNaN(minMaxValues["max"]))
                        minMaxValues["max"] = dat[yVars[i].variable];

                    if (minMaxValues["min"] > dat[yVars[i].variable])
                        minMaxValues["min"] = dat[yVars[i].variable];
                    if (minMaxValues["max"] < dat[yVars[i].variable])
                        minMaxValues["max"] = dat[yVars[i].variable];
                }
                else if (denominator != null) {
                    dat[yVars[i].variable] = d3.sum(v, function (d) { return d[yVars[i].variable]; });
                    //dat[yVars[i].variable+"_rate"] = d3.sum(v, function (d) { return d[yVars[i].variable]; }) / dat.total;
                    dat[yVars[i].variable+"_rate"] = dat[yVars[i].variable] / dat.total;
                    if (isNaN(minMaxValues["min"]))
                        minMaxValues["min"] = dat[yVars[i].variable+"_rate"];
                    if (isNaN(minMaxValues["max"]))
                        minMaxValues["max"] = dat[yVars[i].variable+"_rate"];

                    if (minMaxValues["min"] > dat[yVars[i].variable+"_rate"])
                        minMaxValues["min"] = dat[yVars[i].variable+"_rate"];
                    if (minMaxValues["max"] < dat[yVars[i].variable+"_rate"])
                        minMaxValues["max"] = dat[yVars[i].variable+"_rate"];
                }
            }
            return dat;
        })
        .entries(this.chartData);
    
    // We need to make sure the key second key is sorted because it could make the line chart look very weird.
    // Example -- BS in Athletic Training
    // If the first key only has one data element it will not execute the top level sort.
    // This sorts the subdata -- In this case (semesters or years).
    this.chartData.forEach(function (a) {
        a.values.sort(function (a, b) {
            if (a.key < b.key) return -1;
            if (a.key > b.key) return 1;
            return 0;
        });
    });
    // This sorts the main top level key. This is basically your lines. 
    this.chartData.sort(function (a, b) {
        if (a.key < b.key) return -1;
        if (a.key > b.key) return 1;
        return 0;
    });

    if (this.chartData[0].key === 'undefined') {
        this.chartData[0].key='All';
    }

    this.minMaxValues = minMaxValues;
    this.dataIsSet = true;
}

MultiLineChart.prototype.setData = function (dataset) {
    this.chartData = dataset;       // set the new dataset.
    this.dataIsSet = false;         // set this to false so the object knows it needs summarized.
    this.rollUpData();              // call the rollUpData function so it will do a rollup of the data.  
                                    // this should happen everytime there is a change to the data.         
}

MultiLineChart.prototype.updateChart = function () {
    // Compute the margins. 
    var div_height = this.height;
    var div_width = $(this.htmlObjID).width();
    var width_ = div_width - this.margins.left - this.margins.right;
    var height_ = div_height - this.margins.top - this.margins.bottom;
    var margins = this.margins;

    // If a rate was calculated do this. 
    var measure = this.yVars[0].variable;
    var numerator = null;
    if (this.denominator != null) {
        numerator = measure;
        measure = measure + "_rate";
    }


    var xVar = this.xVar;
    var zVar = this.zVar;

    // Set Range Bounds and the Domain.
    x_ = this.x;
    y_ = this.y;
    z_ = this.z;
    x_.rangeRound([0, width_]);
    x_.domain(this.getXDomain());  
    y_.rangeRound([height_, 0]);
    var rangePercent = (this.minMaxValues["max"] - this.minMaxValues["min"]) / this.minMaxValues["max"];
    if (rangePercent >= .80) 
        y_.domain([0, this.minMaxValues["max"]]);
    else
        y_.domain([this.minMaxValues["min"]*(1-rangePercent), this.minMaxValues["max"]]);
    //y_.domain([0, .6]);
    z_.domain(this.chartData.map(
        function (d) { 
            return d.key; 
        })); 
    this.g.select(".axis--x")
        .attr("transform", "translate(0," + height_ + ")")
        .call(d3.axisBottom(x_));

    var htmlObjID = this.htmlObjID;
    var labelFormat = this.labelFormat;
    this.g.select(".axis--y")
        .call(d3.axisLeft(y_).ticks(10).tickFormat(labelFormat));

    var line = d3.line()
        //.curve(d3.curveBasis)
        .curve(d3.curveMonotoneX)
        .x(function(d) { 
            return x_(d.key)+(x_.bandwidth()/2); 
        })
        .y(function(d) { 
            return y_(d.value[measure]); 
        });

    //
    var series = this.g.selectAll(".line")
        .data(this.chartData);
        //.enter().append("g")
        //  .attr("class", "series");
    
    // Enter
    series.enter().append("path")
        .attr("class", "line")
        .attr("id", function (d) {
            var id = d.key + "_line";
            id = id.replace(/[^A-Z0-9]+/ig, "_");
            return id;
        })
        .attr("d", function(d) { 
            return line(d.values); 
        })
        .style("stroke", function(d) { 
            var z = z_(d.key);
            return z_(d.key); 
        })
        .on("mouseover", function (d) {
            var id = "#" + this.id;

            // IE needs this so it only executes once. It fires multiple times according to this.
            // https://stackoverflow.com/questions/3686132/move-active-element-loses-mouseout-event-in-internet-explorer
            var className = this.className.baseVal;
            if(className === "line highlight")
                return;

            var thisLine = d3.select(id);
            thisLine.attr("class", "line highlight");

            // Move the line to the front.
            var parentNode = this.parentNode;
            parentNode.appendChild(this);

            // Move all the dots to the front. 
            var dotsClass = this.id.replace("_line", "_dots");
            var dots = document.getElementsByClassName(dotsClass);
            var parentNode = dots[0].parentNode;
            var dotIDs = [];
            for (var i=0; i<dots.length; i++) {
                dotIDs.push(dots[i].id);
            }
            for (var i=0; i<dots.length; i++) {
                var element = document.getElementById(dotIDs[i]);
                element.setAttribute("rx", 24);
                element.setAttribute("ry", 14);
                parentNode.appendChild(element);
            }

            // Move all the labels to the front.
            var labelsClass = this.id.replace("_line", "_textLabel");
            var labels = document.getElementsByClassName(labelsClass);
            var parentNode = labels[0].parentNode;
            var labelIDs = [];
            for (var i=0; i<labels.length; i++) {
                labelIDs.push(labels[i].id);
            }
            for (var i=0; i<labels.length; i++) {
                var element = document.getElementById(labelIDs[i]);
                element.style.visibility = 'visible';
                parentNode.appendChild(element);
            }

            // Move all the clear dots to the front.
            var dotsClass = this.id.replace("_line", "_dots2");
            var dots = document.getElementsByClassName(dotsClass);
            var parentNode = dots[0].parentNode;
            var dotIDs = [];
            for (var i=0; i<dots.length; i++) {
                dotIDs.push(dots[i].id);
            }
            for (var i=0; i<dots.length; i++) {
                var element = document.getElementById(dotIDs[i]);
                element.setAttribute("rx", 24);
                element.setAttribute("ry", 14);
                parentNode.appendChild(element);
            }

            // Show tool tip
            var tooltip = d3.select("#toolTip");
            tooltip.attr("class", "toolTip show");
            tooltip.html("<div style='margin-top: 5px; text-align: center;'>" + d.key + "</div>")
                    .style("left", (d3.event.offsetX - 50) + "px")
                    .style("top", (d3.event.pageY - 650 ) + "px");
        })
        .on("mouseout", function (d) {
            var id = "#" + this.id;

            // IE needs this so it only executes once. It fires multiple times according to this.
            // https://stackoverflow.com/questions/3686132/move-active-element-loses-mouseout-event-in-internet-explorer
            var className = this.className.baseVal;
            if(className === "line")
                return;

            var thisLine = d3.select(id);
            thisLine.attr("class", "line");

            // Make all dots radius as 0, makes them invisible. 
            var dotsClass = this.id.replace("_line", "_dots");
            var dots = document.getElementsByClassName(dotsClass);
            var parentNode = dots[0].parentNode;
            var dotIDs = [];
            for (var i=0; i<dots.length; i++) {
                dotIDs.push(dots[i].id);
            }
            for (var i=0; i<dots.length; i++) {
                var element = document.getElementById(dotIDs[i]);
                element.setAttribute("rx", 3);
                element.setAttribute("ry", 3);
            }

            // Make all the labels hidden.
            var labelsClass = this.id.replace("_line", "_textLabel");
            var labels = document.getElementsByClassName(labelsClass);
            var parentNode = labels[0].parentNode;
            var labelIDs = [];
            for (var i=0; i<labels.length; i++) {
                labelIDs.push(labels[i].id);
            }
            for (var i=0; i<labels.length; i++) {
                var element = document.getElementById(labelIDs[i]);
                element.style.visibility = 'hidden';
                //parentNode.appendChild(element);
            }

            // I may not need to do this here.
            // Makes all the clear dots the original size.
            var dotsClass = this.id.replace("_line", "_dots2");
            var dots = document.getElementsByClassName(dotsClass);
            var parentNode = dots[0].parentNode;
            var dotIDs = [];
            for (var i=0; i<dots.length; i++) {
                dotIDs.push(dots[i].id);
            }
            for (var i=0; i<dots.length; i++) {
                var element = document.getElementById(dotIDs[i]);
                element.setAttribute("rx", 3);
                element.setAttribute("ry", 3);
            }

            // Hide the Tool Tip
            var tooltip = d3.select("#toolTip");
            tooltip.attr('class', "toolTip hide");
        })
        .on("mousemove", function(d) {
            var vizControl = $(htmlObjID).offset();
            var tooltip = d3.select("#toolTip");
            //tooltip.style("left", (d3.event.pageX - vizControl.left + 20) + "px")
            //    .style("top", (d3.event.pageY - vizControl.top + 70) + "px");
            tooltip.style("left", (d3.event.pageX - vizControl.left + 20) + "px")
                .style("top", (d3.event.pageY - 40) + "px");
        });
    
    // Update
    series.attr("class", "line")
        .attr("id", function (d) {
            var id = d.key + "_line";
            id = id.replace(/[^A-Z0-9]+/ig, "_");
            return id;
        })
        .attr("d", function(d) { 
            return line(d.values); 
        })
        .style("stroke", function(d) { 
            var z = z_(d.key);
            return z_(d.key); 
        });

    // Exit
    series.exit().remove();

    // Draw the dots. 
    // First flatten the data. 
    var dotsData = [];
    this.chartData.forEach(function (line) {
        //console.log(line);
        line.values.forEach(function (dataPoint) {
            dotsData.push({
                key1: line.key,
                key2: dataPoint.key,
                value: dataPoint.value
            });
        });
    });

    var dots = this.g.selectAll(".dots")
        .data(dotsData);

    // Enter
    dots.enter().append("ellipse")
        .attr("class", function (d) {
            var id = d.key1 + "_dots";
            id = id.replace(/[^A-Z0-9]+/ig, "_");
            return id + " dots";
        })
        .attr("id", function (d) {
            var id = d.key1 + "_" + d.key2 + "_dot";
            id = id.replace(/[^A-Z0-9]+/ig, "_");
            return id;
        })
        .attr("cx", function(d, i) {
            return x_(d.key2)+(x_.bandwidth()/2);
        })
        .attr("cy", function(d, i) {
            return y_(d.value[measure]); 
        })
        .attr("rx", 3)
        .attr("ry", 3)
        .style("fill", function (d) {
            var color = z_(d.key1);
            return z_(d.key1);
        })
        .on("mouseover", function (d,i) {
            /*
            var thisId = this.id;
            var thisClass = this.classList[0];
            var parentNode = this.parentNode;
            //parentNode.appendChild(this);
            // We have to move all the labels and dots back to the front because 
            // they are removed when we mouse out of the line.
            // Move all the dots to the front. 
            //var dotsClass = this.id.replace("_line", "_dots");
            var dots = document.getElementsByClassName(thisClass);
            //var parentNode = dots[0].parentNode;
            var dotIDs = [];
            for (var i=0; i<dots.length; i++) {
                dotIDs.push(dots[i].id);
            }
            for (var i=0; i<dots.length; i++) {
                var element = document.getElementById(dotIDs[i]);
                element.setAttribute("rx", 24);
                element.setAttribute("ry", 14);
                parentNode.appendChild(element);
            }
            
            // Move all the labels to the front.
            var labelsClass = thisClass.replace("_dots", "_textLabel");
            var labels = document.getElementsByClassName(labelsClass);
            var parentNode = labels[0].parentNode;
            var labelIDs = [];
            for (var i=0; i<labels.length; i++) {
                labelIDs.push(labels[i].id);
            }
            for (var i=0; i<labels.length; i++) {
                var element = document.getElementById(labelIDs[i]);
                element.style.visibility = 'visible';
                parentNode.appendChild(element);
            }
            
         
            // Show this triangle
            var triangleId = this.id.replace("_dot", "_triangle");
            var thisTriangle = document.getElementById(triangleId);
            thisTriangle.style.visibility = 'visible';
            parentNode.appendChild(thisTriangle);
            
            // 
            parentNode.appendChild(this);
            var thisDot = d3.select("#" + thisId);
            //thisDot.attr("stroke", "black")
            //    .attr("stroke-width", 2);
            thisDot.style("fill", "black");
            thisDot.style("opacity", .9);
            
            // Keep the line highlighted. 
            var lineId = thisClass.replace("_dots", "_line");
            var thisLine = d3.select("#" + lineId);
            thisLine.attr("class", "line highlight");
         
            var tooltip = d3.select("#toolTip");
            tooltip.attr("class", "toolTip showDot");
            var tooltipHTML = "<div style='margin: 5px; text-align: left;'>";
            tooltipHTML = tooltipHTML + "<div class='toolTipCenter'><span class='toolTipKeyTwo'>" + d.key2 
                + "</span><br/><span  class='toolTipKeyOne'>" + d.key1 + "</span></div><br/>";
            
            tooltipHTML = tooltipHTML + "<table style='width:100%'>";
            if (numerator !== null)  {
                tooltipHTML = tooltipHTML + "<tr><td class='toolTipMeasureTitle'>Cohort: </td><td style='text-align:right'>" + d3.format(',.0f')(d.value.total) + "</td></tr>";
                tooltipHTML = tooltipHTML + "<tr><td class='toolTipMeasureTitle'>Graduated: </td><td style='text-align:right'>" + d3.format(',.0f')(d.value[numerator]) + "</td></tr>";
                tooltipHTML = tooltipHTML + "<tr><td class='toolTipMeasureTitle'>Rate: </td><td style='text-align:right'>" + d3.format(',.2%')(d.value[measure]) + "</td></tr>";
            }
            else {
                tooltipHTML = tooltipHTML + "<tr><td class='toolTipMeasureTitle'>Total: </td><td style='text-align:right'>" + d3.format(',.0f')(d.value[measure]) + "</td></tr>";
            }
            
            tooltipHTML = tooltipHTML + "</table></div>";
            //var htmlID_svg = htmlObjID + '_svg_chart_id';
            var htmlID_svg = "#" + parentNode.parentNode.id;
            var vizControl = $(htmlID_svg).offset();
            tooltip.style("width", "150px");
            tooltip.html(tooltipHTML);

            var toolTipDivHeight = $("#toolTip").outerHeight();

            tooltip.style("left", parseInt(d3.select(this).attr("cx")) + "px")
                .style("top", vizControl.top + parseInt(d3.select(this).attr("cy")) - toolTipDivHeight - 53 + "px");
                //.style("top", vizControl.top + parseInt(d3.select(this).attr("cy")) - margins.top + "px");
            */
        })
        .on("mouseout", function (d,i) { 
            /*
            //var id = "#" + this.id;
            var thisId = this.id;
            
            // Remove triangle
            var triangleId = this.id.replace("_dot", "_triangle");
            var thisTriangle = document.getElementById(triangleId);
            thisTriangle.style.visibility = 'hidden';
            //parentNode.appendChild(thisTriangle);
        
            // Hide the Tool Tip
            var tooltip = d3.select("#toolTip");
            tooltip.attr('class', "toolTip hide");

            // Recolor the dot.
            var thisDot = d3.select("#" + thisId);
            thisDot.style("fill", function (d) {
                return z_(d.key1);
            });
            thisDot.style("opacity", 1);

            // Shrink Dots
            // Make all dots radius as 0, makes them invisible. 
            //var dotsClass = this.id.replace("_line", "_dots");
            var dotsClass = this.classList[0];
            var dots = document.getElementsByClassName(dotsClass);
            var parentNode = dots[0].parentNode;
            var dotIDs = [];
            for (var i=0; i<dots.length; i++) {
                dotIDs.push(dots[i].id);
            }
            for (var i=0; i<dots.length; i++) {
                var element = document.getElementById(dotIDs[i]);
                element.setAttribute("rx", 3);
                element.setAttribute("ry", 3);
            }

             // Make all the labels hidden.
             //var dotsClass = this.classList[0];
             var labelsClass = dotsClass.replace("_dots", "_textLabel");
             var labels = document.getElementsByClassName(labelsClass);
             var parentNode = labels[0].parentNode;
             var labelIDs = [];
             for (var i=0; i<labels.length; i++) {
                 labelIDs.push(labels[i].id);
             }
             for (var i=0; i<labels.length; i++) {
                 var element = document.getElementById(labelIDs[i]);
                 element.style.visibility = 'hidden';
                 //parentNode.appendChild(element);
             }

            // Shrink the line.
            var thisLineId = dotsClass.replace("_dots", "_line");
            var thisLine = d3.select("#" + thisLineId);
            thisLine.attr("class", "line");
            */
        }); 

    // Update
    dots.attr("class", function (d) {
            var id = d.key1 + "_dots";
            id = id.replace(/[^A-Z0-9]+/ig, "_");
            return id + " dots";
        })
        .attr("id", function (d) {
            var id = d.key1 + "_" + d.key2 + "_dot";
            id = id.replace(/[^A-Z0-9]+/ig, "_");
            return id;
        })
        .attr("cx", function(d, i) {
            return x_(d.key2)+(x_.bandwidth()/2);
        })
        .attr("cy", function(d, i) {
            return y_(d.value[measure]); 
        })
        .attr("r", 3)
        .style("fill", function (d) {
            var color = z_(d.key1);
            return z_(d.key1);
        })
        .on("mouseover", function (d,i) {
            /*
            var thisId = this.id;
            var thisClass = this.classList[0];
            var parentNode = this.parentNode;
            //parentNode.appendChild(this);
            // We have to move all the labels and dots back to the front because 
            // they are removed when we mouse out of the line.
            // Move all the dots to the front. 
            //var dotsClass = this.id.replace("_line", "_dots");
            var dots = document.getElementsByClassName(thisClass);
            //var parentNode = dots[0].parentNode;
            var dotIDs = [];
            for (var i=0; i<dots.length; i++) {
                dotIDs.push(dots[i].id);
            }
            for (var i=0; i<dots.length; i++) {
                var element = document.getElementById(dotIDs[i]);
                element.setAttribute("rx", 24);
                element.setAttribute("ry", 14);
                parentNode.appendChild(element);
            }
            
            // Move all the labels to the front.
            var labelsClass = thisClass.replace("_dots", "_textLabel");
            var labels = document.getElementsByClassName(labelsClass);
            var parentNode = labels[0].parentNode;
            var labelIDs = [];
            for (var i=0; i<labels.length; i++) {
                labelIDs.push(labels[i].id);
            }
            for (var i=0; i<labels.length; i++) {
                var element = document.getElementById(labelIDs[i]);
                element.style.visibility = 'visible';
                parentNode.appendChild(element);
            }
            
         
            // Show this triangle
            var triangleId = this.id.replace("_dot", "_triangle");
            var thisTriangle = document.getElementById(triangleId);
            thisTriangle.style.visibility = 'visible';
            parentNode.appendChild(thisTriangle);
            
            // 
            parentNode.appendChild(this);
            var thisDot = d3.select("#" + thisId);
            //thisDot.attr("stroke", "black")
            //    .attr("stroke-width", 2);
            thisDot.style("fill", "black");
            thisDot.style("opacity", .9);
            
            // Keep the line highlighted. 
            var lineId = thisClass.replace("_dots", "_line");
            var thisLine = d3.select("#" + lineId);
            thisLine.attr("class", "line highlight");
         
            var tooltip = d3.select("#toolTip");
            tooltip.attr("class", "toolTip showDot");
            var tooltipHTML = "<div style='margin: 5px; text-align: left;'>";
            tooltipHTML = tooltipHTML + "<div class='toolTipCenter'><span class='toolTipKeyTwo'>" + d.key2 
                + "</span><br/><span  class='toolTipKeyOne'>" + d.key1 + "</span></div><br/>";
            
            tooltipHTML = tooltipHTML + "<table style='width:100%'>";
            if (numerator !== null)  {
                tooltipHTML = tooltipHTML + "<tr><td class='toolTipMeasureTitle'>Cohort: </td><td style='text-align:right'>" + d3.format(',.0f')(d.value.total) + "</td></tr>";
                tooltipHTML = tooltipHTML + "<tr><td class='toolTipMeasureTitle'>Graduated: </td><td style='text-align:right'>" + d3.format(',.0f')(d.value[numerator]) + "</td></tr>";
                tooltipHTML = tooltipHTML + "<tr><td class='toolTipMeasureTitle'>Rate: </td><td style='text-align:right'>" + d3.format(',.2%')(d.value[measure]) + "</td></tr>";
            }
            else {
                tooltipHTML = tooltipHTML + "<tr><td class='toolTipMeasureTitle'>Total: </td><td style='text-align:right'>" + d3.format(',.0f')(d.value[measure]) + "</td></tr>";
            }
            tooltipHTML = tooltipHTML + "</table></div>";
            //var htmlID_svg = htmlObjID + '_svg_chart_id';
            var htmlID_svg = "#" + parentNode.parentNode.id;
            var vizControl = $(htmlID_svg).offset();
            tooltip.style("width", "150px");
            tooltip.html(tooltipHTML);

            var toolTipDivHeight = $("#toolTip").outerHeight();

            tooltip.style("left", parseInt(d3.select(this).attr("cx")) + "px")
                .style("top", vizControl.top + parseInt(d3.select(this).attr("cy")) - toolTipDivHeight - 53 + "px");
                //.style("top", vizControl.top + parseInt(d3.select(this).attr("cy")) - margins.top + "px");
            */
        })
        .on("mouseout", function (d,i) { 
            /*
            //var id = "#" + this.id;
            var thisId = this.id;
            
            // Remove triangle
            var triangleId = this.id.replace("_dot", "_triangle");
            var thisTriangle = document.getElementById(triangleId);
            thisTriangle.style.visibility = 'hidden';
            //parentNode.appendChild(thisTriangle);
        
            // Hide the Tool Tip
            var tooltip = d3.select("#toolTip");
            tooltip.attr('class', "toolTip hide");

            // Recolor the dot.
            var thisDot = d3.select("#" + thisId);
            thisDot.style("fill", function (d) {
                return z_(d.key1);
            });
            thisDot.style("opacity", 1);

            // Shrink Dots
            // Make all dots radius as 0, makes them invisible. 
            //var dotsClass = this.id.replace("_line", "_dots");
            var dotsClass = this.classList[0];
            var dots = document.getElementsByClassName(dotsClass);
            var parentNode = dots[0].parentNode;
            var dotIDs = [];
            for (var i=0; i<dots.length; i++) {
                dotIDs.push(dots[i].id);
            }
            for (var i=0; i<dots.length; i++) {
                var element = document.getElementById(dotIDs[i]);
                element.setAttribute("rx", 3);
                element.setAttribute("ry", 3);
            }

             // Make all the labels hidden.
             //var dotsClass = this.classList[0];
             var labelsClass = dotsClass.replace("_dots", "_textLabel");
             var labels = document.getElementsByClassName(labelsClass);
             var parentNode = labels[0].parentNode;
             var labelIDs = [];
             for (var i=0; i<labels.length; i++) {
                 labelIDs.push(labels[i].id);
             }
             for (var i=0; i<labels.length; i++) {
                 var element = document.getElementById(labelIDs[i]);
                 element.style.visibility = 'hidden';
                 //parentNode.appendChild(element);
             }

            // Shrink the line.
            var thisLineId = dotsClass.replace("_dots", "_line");
            var thisLine = d3.select("#" + thisLineId);
            thisLine.attr("class", "line");
            */
        }); 

    // Exit
    dots.exit().remove();


    // Labels 
    var labelFormat = this.labelFormat;
    var labels = this.g.selectAll(".lineLabels")
        .data(dotsData);

    // Enter
    labels.enter().append("text")
        .attr("class", function (d) {
            var classVal = d.key1 + "_textLabel";
            classVal = classVal.replace(/[^A-Z0-9]+/ig, "_");
            return classVal + " lineLabels";
        })
        .attr("id", function (d) {
            var id = d.key1 + "_" + d.key2 + "_textLabel";
            id = id.replace(/[^A-Z0-9]+/ig, "_");
            return id;
        })
        .attr('fill', function (d, i) {
            var color = z_(d.key1);
            var brightness = perceivedBrightness(color);
            if (brightness > 160) 
                return "#000000";
            else    
                return "#FFFFFF";
        })
        .attr("text-anchor", "middle")
        .attr("x", function(d, i) {
            return x_(d.key2)+(x_.bandwidth()/2);
            //return x_(d.key2)+9;
        })
        .attr("y", function(d, i) {
            return y_(d.value[measure])+4; 
        })
        //.attr("transform", "translate(30,0)")
        .text(function (d) {
            return labelFormat(d.value[measure]);
        });

    // Update
    labels.attr("class", function (d) {
            var classVal = d.key1 + "_textLabel";
            classVal = classVal.replace(/[^A-Z0-9]+/ig, "_");
            return classVal + " lineLabels";
        })
        .attr("id", function (d) {
            var id = d.key1 + "_" + d.key2 + "_textLabel";
            id = id.replace(/[^A-Z0-9]+/ig, "_");
            return id;
        })
        .attr('fill', function (d, i) {
            var color = z_(d.key1);
            var brightness = perceivedBrightness(color);
            if (brightness > 160) 
                return "#000000";
            else    
                return "#FFFFFF";
        })
        .attr("x", function(d, i) {
            return x_(d.key2)+(x_.bandwidth()/2);
            //return x_(d.key2);
        })
        .attr("y", function(d, i) {
            return y_(d.value[measure])+4; 
        })
        //.attr("transform", "translate(30,0)")
        .text(function (d) {
            return labelFormat(d.value[measure]);
        });

    // Exit
    labels.exit().remove();


    
    // Draw triangles for static tooltip
    var shape = d3.symbolTriangle;
    var symbol = d3.symbol().size([80]);
    var triangles = this.g.selectAll(".triangles")
        .data(dotsData);
    
    // Enter
    triangles.enter().append('path')
        .attr("class", "triangles")
        .attr("id", function (d) {
            var id = d.key1 + "_" + d.key2 + "_triangle";
            id = id.replace(/[^A-Z0-9]+/ig, "_");
            return id;
        })
        .attr("d", symbol.type(shape))
        .attr("transform", function(d) { 
            var x =  x_(d.key2)+(x_.bandwidth()/2);
            var y = y_(d.value[measure]) - 20;
            return "translate(" + x + "," + y + ") rotate(-180)"; 
        })   
        .style("fill", "black")
        .style("visibility", "hidden");

    // Update
    triangles.attr("class", "triangles")
        .attr("id", function (d) {
            var id = d.key1 + "_" + d.key2 + "_triangle";
            id = id.replace(/[^A-Z0-9]+/ig, "_");
            return id;
        })
        .attr("transform", function(d) { 
            var x =  x_(d.key2)+(x_.bandwidth()/2);
            var y = y_(d.value[measure]) - 20;
            return "translate(" + x + "," + y + ") rotate(-180)"; 
        })   
        .style("fill", "black")
        .style("visibility", "hidden");

    // Exit
    triangles.exit().remove();
    

    // Create some light opacity dots that are always in front of the main dots.
    // I'm hoping this will take away the flicker problem that is caused by the labels.
    var dots2 = this.g.selectAll(".dots2")
    .data(dotsData);

    // Enter
    dots2.enter().append("ellipse")
        .attr("class", function (d) {
            var id = d.key1 + "_dots2";
            id = id.replace(/[^A-Z0-9]+/ig, "_");
            return id + " dots2";
        })
        .attr("id", function (d) {
            var id = d.key1 + "_" + d.key2 + "_dot2";
            id = id.replace(/[^A-Z0-9]+/ig, "_");
            return id;
        })
        .attr("cx", function(d, i) {
            return x_(d.key2)+(x_.bandwidth()/2);
        })
        .attr("cy", function(d, i) {
            return y_(d.value[measure]); 
        })
        .attr("rx", 3)
        .attr("ry", 3)
        .style("fill", "#FF0000")
        .style("opacity", .0)
        .on("mouseover", function (d,i) {
            var thisId = this.id;

            //var thisClass = this.classList[0];
            var thisClass = this.className.baseVal.split(" ", 1)[0];
            var parentNode = this.parentNode;

            // IE needs this so it only executes once. It fires multiple times according to this.
            // https://stackoverflow.com/questions/3686132/move-active-element-loses-mouseout-event-in-internet-explorer
            // Show this triangle
            var triangleId = this.id.replace("_dot2", "_triangle");
            var thisTriangle = document.getElementById(triangleId);
            if (thisTriangle.style.visibility == 'visible') 
                return;
            thisTriangle.style.visibility = 'visible';
            parentNode.appendChild(thisTriangle);

            // Bring this dot to the front.
            var element = document.getElementById(thisId);
            element.setAttribute("rx", 24);
            element.setAttribute("ry", 14);
            parentNode.appendChild(element);

            // Move all the background dots to the front.
            // This is the dots colored with the line color.
            var dotsClass = thisClass.replace("_dots2", "_dots");
            var dots = document.getElementsByClassName(dotsClass);
            var parentNode = dots[0].parentNode;
            var dotIDs = [];
            for (var i=0; i<dots.length; i++) {
                dotIDs.push(dots[i].id);
            }
            for (var i=0; i<dots.length; i++) {
                var element = document.getElementById(dotIDs[i]);
                element.setAttribute("rx", 24);
                element.setAttribute("ry", 14);
                parentNode.insertBefore(element, this);
            }

            // Move all the labels to the front.
            var labelsClass = thisClass.replace("_dots2", "_textLabel");
            var labels = document.getElementsByClassName(labelsClass);
            var parentNode = labels[0].parentNode;
            var labelIDs = [];
            for (var i=0; i<labels.length; i++) {
                labelIDs.push(labels[i].id);
            }
            for (var i=0; i<labels.length; i++) {
                var element = document.getElementById(labelIDs[i]);
                element.style.visibility = 'visible';
                parentNode.insertBefore(element, this);
            }
         


            // Move all cover dots to the front. 
            var coverDots = document.getElementsByClassName(thisClass);
            var parentNode = coverDots[0].parentNode;
            var coverDotIDs = [];
            for (var i=0; i<coverDots.length; i++) {
                coverDotIDs.push(coverDots[i].id);
            }
            for (var i=0; i<coverDots.length; i++) {
                if (thisId != coverDotIDs[i]) {
                    var element = document.getElementById(coverDotIDs[i]);
                    element.setAttribute("rx", 24);
                    element.setAttribute("ry", 14);
                    parentNode.insertBefore(element, this);
                }
            }
            
            // Keep the line highlighted. 
            var lineId = thisClass.replace("_dots2", "_line");
            var thisLine = d3.select("#" + lineId);
            thisLine.attr("class", "line highlight");
         
            var tooltip = d3.select("#toolTip");
            tooltip.attr("class", "toolTip showDot");
            var tooltipHTML = "<div style='margin: 5px; text-align: left;'>";
            tooltipHTML = tooltipHTML + "<div class='toolTipCenter'><span class='toolTipKeyTwo'>" + d.key2 
                + "</span><br/><span  class='toolTipKeyOne'>" + d.key1 + "</span></div><br/>";
            
            tooltipHTML = tooltipHTML + "<table style='width:100%'>";
            if (numerator !== null)  {
                tooltipHTML = tooltipHTML + "<tr><td class='toolTipMeasureTitle'>Cohort: </td><td style='text-align:right'>" + d3.format(',.0f')(d.value.total) + "</td></tr>";
                tooltipHTML = tooltipHTML + "<tr><td class='toolTipMeasureTitle'>Graduated: </td><td style='text-align:right'>" + d3.format(',.0f')(d.value[numerator]) + "</td></tr>";
                tooltipHTML = tooltipHTML + "<tr><td class='toolTipMeasureTitle'>Rate: </td><td style='text-align:right'>" + d3.format(',.2%')(d.value[measure]) + "</td></tr>";
            }
            else {
                tooltipHTML = tooltipHTML + "<tr><td class='toolTipMeasureTitle'>Total: </td><td style='text-align:right'>" + d3.format(',.0f')(d.value[measure]) + "</td></tr>";
            }
            tooltipHTML = tooltipHTML + "</table></div>";
            //var htmlID_svg = htmlObjID + '_svg_chart_id';
            var htmlID_svg = "#" + parentNode.parentNode.id;
            var vizControl = $(htmlID_svg).offset();
            tooltip.style("width", "150px");
            tooltip.html(tooltipHTML);

            var toolTipDivHeight = $("#toolTip").outerHeight();

            tooltip.style("left", parseInt(d3.select(this).attr("cx")) + "px")
                .style("top", vizControl.top + parseInt(d3.select(this).attr("cy")) - toolTipDivHeight - 53 + "px");
                //.style("top", vizControl.top + parseInt(d3.select(this).attr("cy")) - margins.top + "px");
            
        })
        .on("mouseout", function (d,i) {
            //var id = "#" + this.id;
            var thisId = this.id;
            //var thisClass = this.classList[0];
            var thisClass = this.className.baseVal.split(" ", 1)[0];

            /*var element = document.getElementById(thisId);
            // IE needs this so it only executes once. It fires multiple times according to this.
            // https://stackoverflow.com/questions/3686132/move-active-element-loses-mouseout-event-in-internet-explorer
            if (element.rx.baseVal.value == 3)
                return;
            */
            
            // Remove triangle
            var triangleId = this.id.replace("_dot2", "_triangle");
            var thisTriangle = document.getElementById(triangleId);
            if (thisTriangle.style.visibility == 'hidden')
                return;
            thisTriangle.style.visibility = 'hidden';
        
            // Hide the Tool Tip
            var tooltip = d3.select("#toolTip");
            tooltip.attr('class', "toolTip hide");

            // Shrink Dots
            // Make all dots radius as 0, makes them invisible. 
            var dotsClass = thisClass.replace("_dots2", "_dots");
            var dots = document.getElementsByClassName(dotsClass);
            var parentNode = dots[0].parentNode;
            var dotIDs = [];
            for (var i=0; i<dots.length; i++) {
                dotIDs.push(dots[i].id);
            }
            for (var i=0; i<dots.length; i++) {
                var element = document.getElementById(dotIDs[i]);
                element.setAttribute("rx", 3);
                element.setAttribute("ry", 3);
            }
            
             // Make all the labels hidden.
             var labelsClass = dotsClass.replace("_dots", "_textLabel");
             var labels = document.getElementsByClassName(labelsClass);
             var parentNode = labels[0].parentNode;
             var labelIDs = [];
             for (var i=0; i<labels.length; i++) {
                 labelIDs.push(labels[i].id);
             }
             for (var i=0; i<labels.length; i++) {
                 var element = document.getElementById(labelIDs[i]);
                 element.style.visibility = 'hidden';
             }
        
            // Shrink the line.
            //var dotsClass = this.classList[0];
            var dotsClass = this.className.baseVal.split(" ", 1)[0];
            var thisLineId = dotsClass.replace("_dots2", "_line");
            var thisLine = d3.select("#" + thisLineId);
            thisLine.attr("class", "line");

            // Shrink the cover dots.
            var dots = document.getElementsByClassName(thisClass);
            var parentNode = dots[0].parentNode;
            var dotIDs = [];
            for (var i=0; i<dots.length; i++) {
                dotIDs.push(dots[i].id);
            }
            for (var i=0; i<dots.length; i++) {
                var element = document.getElementById(dotIDs[i]);
                element.setAttribute("rx", 3);
                element.setAttribute("ry", 3);
                parentNode.appendChild(element);
            }
        });

    // Update
    // I have to have mouse events on the update because tooltip values change.
    // If not, it does not pick up the updated data.
    dots2.attr("class", function (d) {
        var id = d.key1 + "_dots2";
        id = id.replace(/[^A-Z0-9]+/ig, "_");
        return id + " dots2";
    })
    .attr("id", function (d) {
        var id = d.key1 + "_" + d.key2 + "_dot2";
        id = id.replace(/[^A-Z0-9]+/ig, "_");
        return id;
    })
    .attr("cx", function(d, i) {
        return x_(d.key2)+(x_.bandwidth()/2);
    })
    .attr("cy", function(d, i) {
        return y_(d.value[measure]); 
    })
    .attr("r", 3)
    .style("fill", "#FF0000")
    .style("opacity", .0)
    .on("mouseover", function (d,i) {
        var thisId = this.id;
        //var thisClass = this.classList[0];
        var thisClass = this.className.baseVal.split(" ", 1)[0];
        var parentNode = this.parentNode;

        // IE needs this so it only executes once. It fires multiple times according to this.
        // https://stackoverflow.com/questions/3686132/move-active-element-loses-mouseout-event-in-internet-explorer
        // Show this triangle
        var triangleId = this.id.replace("_dot2", "_triangle");
        var thisTriangle = document.getElementById(triangleId);
        if (thisTriangle.style.visibility == 'visible') 
            return;
        thisTriangle.style.visibility = 'visible';
        parentNode.appendChild(thisTriangle);

        // Bring this dot to the front.
        var element = document.getElementById(thisId);
        element.setAttribute("rx", 24);
        element.setAttribute("ry", 14);
        parentNode.appendChild(element);

        // Move all the background dots to the front.
        // This is the dots colored with the line color.
        var dotsClass = thisClass.replace("_dots2", "_dots");
        var dots = document.getElementsByClassName(dotsClass);
        var parentNode = dots[0].parentNode;
        var dotIDs = [];
        for (var i=0; i<dots.length; i++) {
            dotIDs.push(dots[i].id);
        }
        for (var i=0; i<dots.length; i++) {
            var element = document.getElementById(dotIDs[i]);
            element.setAttribute("rx", 24);
            element.setAttribute("ry", 14);
            parentNode.insertBefore(element, this);
        }

        // Move all the labels to the front.
        var labelsClass = thisClass.replace("_dots2", "_textLabel");
        var labels = document.getElementsByClassName(labelsClass);
        var parentNode = labels[0].parentNode;
        var labelIDs = [];
        for (var i=0; i<labels.length; i++) {
            labelIDs.push(labels[i].id);
        }
        for (var i=0; i<labels.length; i++) {
            var element = document.getElementById(labelIDs[i]);
            element.style.visibility = 'visible';
            parentNode.insertBefore(element, this);
        }
     
        // Show this triangle
        var triangleId = this.id.replace("_dot2", "_triangle");
        var thisTriangle = document.getElementById(triangleId);
        thisTriangle.style.visibility = 'visible';
        parentNode.appendChild(thisTriangle);

        // Move all cover dots to the front. 
        var coverDots = document.getElementsByClassName(thisClass);
        var parentNode = coverDots[0].parentNode;
        var coverDotIDs = [];
        for (var i=0; i<coverDots.length; i++) {
            coverDotIDs.push(coverDots[i].id);
        }
        for (var i=0; i<coverDots.length; i++) {
            if (thisId != coverDotIDs[i]) {
                var element = document.getElementById(coverDotIDs[i]);
                element.setAttribute("rx", 24);
                element.setAttribute("ry", 14);
                parentNode.insertBefore(element, this);
            }
        }
        
        // Keep the line highlighted. 
        var lineId = thisClass.replace("_dots2", "_line");
        var thisLine = d3.select("#" + lineId);
        thisLine.attr("class", "line highlight");
     
        var tooltip = d3.select("#toolTip");
        tooltip.attr("class", "toolTip showDot");
        var tooltipHTML = "<div style='margin: 5px; text-align: left;'>";
        tooltipHTML = tooltipHTML + "<div class='toolTipCenter'><span class='toolTipKeyTwo'>" + d.key2 
            + "</span><br/><span  class='toolTipKeyOne'>" + d.key1 + "</span></div><br/>";
        
        tooltipHTML = tooltipHTML + "<table style='width:100%'>";
        if (numerator !== null)  {
            tooltipHTML = tooltipHTML + "<tr><td class='toolTipMeasureTitle'>Cohort: </td><td style='text-align:right'>" + d3.format(',.0f')(d.value.total) + "</td></tr>";
            tooltipHTML = tooltipHTML + "<tr><td class='toolTipMeasureTitle'>Graduated: </td><td style='text-align:right'>" + d3.format(',.0f')(d.value[numerator]) + "</td></tr>";
            tooltipHTML = tooltipHTML + "<tr><td class='toolTipMeasureTitle'>Rate: </td><td style='text-align:right'>" + d3.format(',.2%')(d.value[measure]) + "</td></tr>";
        }
        else {
            tooltipHTML = tooltipHTML + "<tr><td class='toolTipMeasureTitle'>Total: </td><td style='text-align:right'>" + d3.format(',.0f')(d.value[measure]) + "</td></tr>";
        }
        tooltipHTML = tooltipHTML + "</table></div>";
        //var htmlID_svg = htmlObjID + '_svg_chart_id';
        var htmlID_svg = "#" + parentNode.parentNode.id;
        var vizControl = $(htmlID_svg).offset();
        tooltip.style("width", "150px");
        tooltip.html(tooltipHTML);

        var toolTipDivHeight = $("#toolTip").outerHeight();

        tooltip.style("left", parseInt(d3.select(this).attr("cx")) + "px")
            .style("top", vizControl.top + parseInt(d3.select(this).attr("cy")) - toolTipDivHeight - 53 + "px");
            //.style("top", vizControl.top + parseInt(d3.select(this).attr("cy")) - margins.top + "px");
        
    })
    .on("mouseout", function (d,i) {
        //var id = "#" + this.id;
        var thisId = this.id;
        //var thisClass = this.classList[0];
        var thisClass = this.className.baseVal.split(" ", 1)[0];
        
        // Remove triangle
        var triangleId = this.id.replace("_dot2", "_triangle");
        var thisTriangle = document.getElementById(triangleId);
        if (thisTriangle.style.visibility == 'hidden')
            return;
        thisTriangle.style.visibility = 'hidden';
    
        // Hide the Tool Tip
        var tooltip = d3.select("#toolTip");
        tooltip.attr('class', "toolTip hide");

        // Shrink Dots
        // Make all dots radius as 0, makes them invisible. 
        var dotsClass = thisClass.replace("_dots2", "_dots");
        var dots = document.getElementsByClassName(dotsClass);
        var parentNode = dots[0].parentNode;
        var dotIDs = [];
        for (var i=0; i<dots.length; i++) {
            dotIDs.push(dots[i].id);
        }
        for (var i=0; i<dots.length; i++) {
            var element = document.getElementById(dotIDs[i]);
            element.setAttribute("rx", 3);
            element.setAttribute("ry", 3);
        }
        
         // Make all the labels hidden.
         var labelsClass = dotsClass.replace("_dots", "_textLabel");
         var labels = document.getElementsByClassName(labelsClass);
         var parentNode = labels[0].parentNode;
         var labelIDs = [];
         for (var i=0; i<labels.length; i++) {
             labelIDs.push(labels[i].id);
         }
         for (var i=0; i<labels.length; i++) {
             var element = document.getElementById(labelIDs[i]);
             element.style.visibility = 'hidden';
         }
    
        // Shrink the line.
        //var dotsClass = this.classList[0];
        var dotsClass = this.className.baseVal.split(" ", 1)[0];
        var thisLineId = dotsClass.replace("_dots2", "_line");
        var thisLine = d3.select("#" + thisLineId);
        thisLine.attr("class", "line");

        // Shrink the cover dots.
        var dots = document.getElementsByClassName(thisClass);
        var parentNode = dots[0].parentNode;
        var dotIDs = [];
        for (var i=0; i<dots.length; i++) {
            dotIDs.push(dots[i].id);
        }
        for (var i=0; i<dots.length; i++) {
            var element = document.getElementById(dotIDs[i]);
            element.setAttribute("rx", 3);
            element.setAttribute("ry", 3);
            parentNode.appendChild(element);
        }
    });

    // Exit
    dots2.exit().remove();
}

MultiLineChart.prototype.initialChart = function () {
    // if svg already exists then no need to recreated everything again.
    if(this.svg !== null)
        return;

    var htmlID = this.htmlObjID.substring(1);
    // Create the svg drawing area. 
    this.svg = d3.select(this.htmlObjID).append('svg')
        .attr('class', htmlID + '_svg_chart')
        .attr('id', htmlID + '_svg_chart_id')
        .attr('width', '100%')
        .attr('height', this.height + "px");
    this.g = this.svg.append("g")
        .attr("id", htmlID + '_g_chart_id')
        .attr("transform", "translate(" + this.margins.left + "," + this.margins.top + ")");
    this.g.attr('height', '100%');
    this.g.append("g").attr("class", "axis axis--x");
    this.g.append("g").attr("class", "axis axis--y");

    this.x = d3.scaleBand().padding(0.1);
    this.y = d3.scaleLinear();
    this.z = d3.scaleOrdinal(d3.schemeCategory20); // 20 colors. 
    //this.z = d3.scaleOrdinal(d3.schemePastel1);
}

MultiLineChart.prototype.drawChart = function (dataset) {
    // call and set the new dataset.
    if (dataset != null)
        this.setData(dataset); 

    // Create the chart objects. Note, this will not recreate them when they are already created.
    this.initialChart();

    // This should put the data on the screen.
    this.updateChart();

}

MultiLineChart.prototype.removeFromBrowser = function () {
    // remove bar chart from browser
    var htmlID = "." + this.htmlObjID.substring(1) + "_svg_chart";
    $(htmlID).remove();
}


// Takes a hex color and returns the perceived brightness from 0 to 255.
//      hexColor - String starting with a hashtag #.
function perceivedBrightness(hexColor) {
    hex = hexColor.replace('#','');
    r = parseInt(hex.substring(0,2), 16);
    g = parseInt(hex.substring(2,4), 16);
    b = parseInt(hex.substring(4,6), 16);
    brightness = Math.round(Math.sqrt(0.299*r*r + 0.587*g*g + 0.114*b*b));
    return brightness;
}
