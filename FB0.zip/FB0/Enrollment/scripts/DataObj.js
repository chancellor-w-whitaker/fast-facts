class DataObj {
    constructor() {
        this.keys = [];
        this.originalData = [];         // Original input data - no changes.
        this.data = [];
        this.filters = [];
    }

    initializeData(inData) {
        if (this.originalData.length == 0) {
            this.originalData = JSON.parse(JSON.stringify(inData));
            this.keys = d3.keys(this.originalData[0]).filter(function(d) { return d; });

            // convert to numeric. 
            for(var i = 0; i<this.originalData.length; i++){
                for(var j = 0; j<this.keys.length; j++) {    
                    var comp = this.originalData[i][this.keys[j]].localeCompare("");
                    if (comp != 0)
                        this.originalData[i][this.keys[j]] = +this.originalData[i][this.keys[j]]; 
                    else    
                        this.originalData[i][this.keys[j]] = null;
                }
            }
        }
        this.applyFilters(); 
    }


    insertFilterObj(varName, varValue) {
        // Make sure it does not already exist. 
        var object = { "varName": varName, "varValue": varValue };
        for (var i = 0; i < this.filters.length; i++) {
            if (JSON.stringify(object) === JSON.stringify(this.filters[i])) {
                return;
            }
        }
        // If we make it here then it does not exist, insert the filter. 
        this.filters.push(object);
    }

    removeAllFilters(varName) {
        // remove all filters related to a variable.
        var filters = this.filters.filter(function (d) {
            return d.varName !== varName;
        });
        this.filters = filters;
    }

    removeSpecificFilter(varName, value) {
        // remove a specific filter.
        var filters = this.filters.filter(function (d) {
            if (d.varName !== varName && d.varValue !== value) {
                return false;
            }
            return true;
        });
        this.filters = filters;
    }

    applyFilters() {
        // reset the data every time. 
        this.data = JSON.parse(JSON.stringify(this.originalData));

        // loop through data and filters 
        var newData = [];
        var data = this.data;
        var filters = this.filters;
        var numOfFilterVars = d3.nest().key(function(d) {return d.varName}).entries(filters).length;
        var matches = 0;
        if (filters.length > 0) {
            for(var i=0; i<data.length; i++) {
                for(var j=0; j<filters.length; j++) {
                    if (+data[i][filters[j].varName] === +filters[j].varValue) {
                        matches++;
                        if (matches === numOfFilterVars) {
                            newData.push(data[i]);
                            break;
                        }
                    }
                }
                matches = 0;
            }
            // Set data equal to the new filtered data.
            this.data = JSON.parse(JSON.stringify(newData));
        }      
    }

    
    // set(inData) {
    //     // get all the buttons where we select something. 
    //     // loop through them building filters based on what is selected. 
    //     var buttonFilters = document.querySelectorAll("[id^=select]");
    //     for (var i = 0; i < buttonFilters.length; i++) {
    //         var buttonID = buttonFilters[i].id;
    //         var last_char = buttonID.substr(buttonID.length - 1, 1);
    //         if (last_char == '_') {
    //             var varName = buttonID.slice(6, buttonID.length - 1);
    //             this.insertFilterObj(varName, buttonFilters[i].innerText);
    //         }
    //     }
    //     // filter the data. 
    //     // loop through all selected filters. 
    //     var selected = this.filters;
    //     for (var i = 0; i < selected.length; i++) {
    //         // loop through all the data.
    //         for (var j = 0; j < inData.length; j++) {
    //             // if the filter value is equal to the data value then push the data to a new array.
    //             if (inData[j][selected[i].varName] == selected[i].varValue) {
    //                 this.data.push(inData[j]);
    //             }
    //         }
    //         // reset inData to the previously filtered data.
    //         // and reset the previously filtered data to nothing. It's like we are start over with a smaller dataset. 
    //         inData = this.data;
    //         this.data = [];
    //     }
    //     this.data = inData;
    // }

    // generateYears() {
    //     var generatedData = [];

    //     // Get the first year.
    //     var firstYear = this.data.filter(function(d){return d.year == 0;});
    //     var secondYear = this.data.filter(function(d){return d.year == 1;}); // year 2 already has spring generated from SAS.

    //     for (var i = 0; i < this.YearsToView; i++) {
    //         var yearData = [];
    //         if (i==0) {
    //             Array.prototype.push.apply(generatedData, firstYear);  // Second year gets pushed also, but the rest is based on this year.
    //         }
    //         else if (i==1) {
    //             Array.prototype.push.apply(generatedData, secondYear);  // Second year gets pushed also, but the rest is based on this year.
    //         }
    //         else {
    //             yearData = JSON.parse(JSON.stringify(secondYear));
    //             //yearData[CalendarVar] = i;  // set the calendar variable to i.
                
    //             yearData.map(function(x) {
    //                 x.year = i;
    //             });
                
    //             Array.prototype.push.apply(generatedData,yearData); 
    //         }
    //     }
    //     this.data = JSON.parse(JSON.stringify(generatedData));
    //     //this.performCalculations();
    // }

    // getListOfColumns(type) {
    //     // type=1 : is charges
    //     // type=2 : is hours
    //     // type=3 : is the max
    //     var keepOnly = ["TUKY", "TUNR", "TUOL", "TUVT", "TGKY", "TGNR", "TGOL", "TGVT", "ZZZZ", "FEE_"]
    //     var columns = [];
    //     for (var i=0; i<this.keys.length; i++) {
    //         var stringIn;
    //         var keepIt = false;

    //         // Do this if we want to exclude online programs detail codes.
    //         if(this.noOnlinePrograms == true) {
    //             stringIn = this.keys[i].substring(0,4);
    //             for(var j=0; j<keepOnly.length; j++) {
    //                 if (stringIn === keepOnly[j]) {
    //                     keepIt = true;
    //                     break;
    //                 }
    //             }
    //         }
    //         else {
    //             keepIt = true;
    //         }

    //         stringIn = this.keys[i].substring(4);
    //         var stringComp1 = stringIn.localeCompare('_charges');
    //         if (stringComp1 == 0 && type == 1 && keepIt == true) 
    //             columns.push(this.keys[i]);
    //         stringComp1 = stringIn.localeCompare('_hours');
    //         if (stringComp1 == 0 && type == 2 && keepIt == true) 
    //             columns.push(this.keys[i]);
    //         stringComp1 = stringIn.localeCompare('_max');
    //         if (stringComp1 == 0 && type == 3 && keepIt == true) 
    //             columns.push(this.keys[i]);
    //     }
    //     return columns;
    // }

    // sumColumns(theseColumns, inData) {
    //     var sum = 0;
    //     for(var i = 0; i < theseColumns.length; i++) {
    //         sum = sum + inData[theseColumns[i]];
    //     }
    //     return sum;
    // }

    // increaseTuition(theseColumns, inData) {
    //     for(var i = 0; i < theseColumns.length; i++) {
    //         var new_tuition = inData[theseColumns[i]]*Math.pow(1+this.tuitionIncrease, inData.year-1);
    //         inData[theseColumns[i]] = new_tuition;
    //     }
    // }

    // determineMaxCharge(inData) {
    //     // use residency code if there are no TUKY, TUNR, etc.

    //     // This portion takes care of the hours part. 
    //     if (inData.TUKY_hours > 0)
    //         return inData.TUKY_max;
    //     else if (inData.TUNR_hours > 0) 
    //         return inData.TUNR_max;
    //     else if (inData.TUOV_hours > 0)
    //         return inData.TUOV_max;
    //     else if (inData.TUVT_hours > 0)
    //     return inData.TUVT_max;

    //     // If nothing has returned then look at undergraduates. 
    //     if (level[inData.level].localeCompare('Undergraduate') == 0) {
    //         if (inData.TUOL_hours > 0 && this.noOnlineSurcharge == true) {
    //             // In-State vs Out-of-State
    //             if (residencyType[inData.residencyType].localeCompare('In-State') == 0) 
    //                 return inData.TUKY_max;
    //             else
    //                 return inData.TUNR_max;
    //         }
    //     }

    //     // return the maximum that nobody should ever get to.
    //     return 999999.99;
    // }

    // calculateSurchargeRemoval(inData, tuitionType) {
    //     // This seems to work fine at treating TUOL as a regular course.
    //     // tuitionType can be TUKY, TUNR, TUOV, TUVT.
    //     var hoursVar=tuitionType + "_hours";
    //     var tuitionVar=tuitionType + "_charges";
    //     var maxVar=tuitionType + "_max";
    //     var rate=0;
    //     var newTuition=0;

    //     if (inData[hoursVar] > 0) 
    //         rate = inData[tuitionVar]/inData[hoursVar];                 // determine the rate.
    //     else
    //         rate = inData[maxVar]/12; 

    //     inData[hoursVar] = inData[hoursVar] + inData.TUOL_hours;    // add online hours to the hours var.
    //     newTuition = inData[hoursVar] * rate;                       // calculate the new tuition based on the new hours.

    //     if (newTuition > inData[maxVar] && inData[hoursVar] > 12) {
    //         inData.ZZZZ_hours = inData.ZZZZ_hours + (inData[hoursVar]-12); // add extra hours to zzzz
    //         inData[hoursVar] = 12;
    //         inData[tuitionVar] = inData[maxVar];
    //     }
    //     else {
    //         inData[tuitionVar] = newTuition;
    //     }

    //     // zero out the TUOL.
    //     inData.TUOL_hours = 0;
    //     inData.TUOL_charges = 0;
    // }

    // noOnlineSurchargeCal(inData) {
    //     /*
    //         Non-resident online surcharge removal is moving from the online charge to the non-resident charge.
    //         So, it goes up considerably.
    //     */

    //     if (this.noOnlineSurcharge != true)
    //         return;

    //     if (inData.TUOL_hours > 0) {
    //         if (inData.TUKY_hours > 0)
    //             this.calculateSurchargeRemoval(inData, "TUKY");
    //         else if (inData.TUNR_hours > 0) 
    //             this.calculateSurchargeRemoval(inData, "TUNR");
    //         else if (inData.TUOV_hours > 0)
    //             this.calculateSurchargeRemoval(inData, "TUOV");
    //         else if (inData.TUVT_hours > 0)
    //             this.calculateSurchargeRemoval(inData, "TUVT");
    //         else if (residencyType[inData.residencyType].localeCompare('In-State') == 0)
    //             this.calculateSurchargeRemoval(inData, "TUKY");
    //         else if (residencyType[inData.residencyType].localeCompare('Out-of-State') == 0)
    //             this.calculateSurchargeRemoval(inData, "TUNR");           
    //     }
    // }

    // chargeAfterCutOffHours(inData) {
    //     var rate = 0;
    //     var max = 0;
    //     var hours = 0;

    //    // I don't think I need to multiply by the cutOffHoursRate to get the rate. This happens later.
    //    if (inData.TUKY_hours == 12) { // Use the Kentucky Resident Rate. 
    //         rate = (inData.TUKY_charges/inData.TUKY_hours);
    //         max = inData.TUKY_max;
    //         hours = inData.TUKY_hours + inData.ZZZZ_hours;
    //     }
    //     else if (inData.TUNR_hours == 12) { // Use the Non-Resident Rate. 
    //         rate = (inData.TUNR_charges/inData.TUNR_hours);
    //         max = inData.TUNR_max;
    //         hours = inData.TUNR_hours + inData.ZZZZ_hours;
    //     }
    //     else if (inData.TUOV_hours == 12) { // Use the Online Veteran Rate. 
    //         rate = (inData.TUOV_charges/inData.TUOV_hours);
    //         max = inData.TUOV_max;
    //         hours = inData.TUOV_hours + inData.ZZZZ_hours;
    //     }
    //     else if (inData.TUVT_hours == 12) { // Use the Veteran Rate. 
    //         rate = (inData.TUVT_charges/inData.TUVT_hours);
    //         max = inData.TUVT_max;
    //         hours = inData.TUVT_hours + inData.ZZZZ_hours;
    //     }

    //     inData.ZZZZ_charges = 0;
    //     if (hours > 12) {
    //         var hoursAbove = hours - this.cutOffHours;
    //         if (hoursAbove > 0) {

    //             //if (inData.year == 4)
    //             //    console.log("");
    //             // Account for a loss rate if we start charging for hours above. 
    //             var hoursToKeep = hoursAbove;
    //             if (this.cutOffHoursLoss != 0)
    //                 hoursToKeep = hoursAbove*Math.pow(1-this.cutOffHoursLoss, inData.year-1);
    //                 //hoursToRemove = hoursAbove*Math.pow(1-this.cutOffHoursLoss, inData.year-1);

    //             //hoursAbove = hoursAbove - hoursToRemove;
    //             hoursAbove = hoursToKeep;

    //             inData.ZZZZ_charges = (rate*this.cutOffHoursRate)*hoursAbove;  
    //             //total_tuition = this.sumColumns(tuition_columns, inData);
    //             //inData.new_tuition = total_tuition; 
    //         }
    //     }
    // }

    // applyModals(inData){
    //     // loop through the types of modals.
    //     for(var i=0; i<this.modals.length; i++){
    //         var modal = this.modals[i];
    //         // loop through the variables for the modal.
    //         for(var j=0; j<modal.variable.length; j++) {
    //             var variable = modal.variable[j];
    //             var value = modal.getModalValue(inData[variable]); // get the value for the code.
    //             var current = inData.FEE__charges;
    //             // Check the current value vs the new value.
    //             // If the new value is large, replace the current value with it.
    //             if (value>current)
    //                 inData.FEE__charges = value;
    //         }
    //     }
    // }

    // performCalculations() {
    //     var tuition_columns = this.getListOfColumns(1);
    //     var hour_columns = this.getListOfColumns(2);
    //     var max_columns = this.getListOfColumns(3);

    //     // Add growth samples to years from 2 and forward.
    //     // It is reflected in both lines.
    //     for (var i=2; i<this.YearsToView; i++) {
    //         this.randomSample(i);
    //     }

    //     // any data 2 and above for year will need to have computations done on values.
    //     for (var i=0; i<this.data.length; i++){
    //         //var total_tuition = this.sumColumns(tuition_columns, this.data[i]);
    //         this.data[i].original_total_tuition = this.sumColumns(tuition_columns, this.data[i]); // Growth Increase is included.
            
    //         //var total_hours = this.sumColumns(hour_columns, this.data[i]);
    //         //this.data[i].total_hours = total_hours;

    //         // These will hold the new computed values. 
    //         //this.data[i].new_tuition = this.data[i].total_tuition;
    //         //this.data[i].new_total_hours = this.data[i].total_hours;

    //         if (this.data[i].year >= 2) {
    //             // Account for tuition increases -- Increase the max too. 
    //             // Currently increases in tuition are reflect on both lines.
    //             this.increaseTuition(tuition_columns, this.data[i]);
    //             //total_tuition = this.sumColumns(tuition_columns, this.data[i]);
    //             //this.data[i].new_tuition = total_tuition;
    //             this.increaseTuition(max_columns, this.data[i]);
    //             this.data[i].tuition_inc_total_tuition = this.sumColumns(tuition_columns, this.data[i]); // Growth Increase is included.
                

    //             // Online Surcharge removal or not. 
    //             this.noOnlineSurchargeCal(this.data[i]);
    //             this.data[i].surcharge_total_tuition = this.sumColumns(tuition_columns, this.data[i]); // Growth Increase is included.

    //             // Account for above the cut off hours
    //             // ZZZZ_hours are those above 12, considered free hours so there shouldn't be charges initially.
    //             // This should happen after surcharge call because hours are moved around in that functions.
    //             this.chargeAfterCutOffHours(this.data[i]);
    //             this.data[i].cutoff_total_tuition = this.sumColumns(tuition_columns, this.data[i]); // Growth Increase is included.

    //             // Apply the college/department/program fee.
    //             // It takes the max of the three potential fees. 
    //             // Modals are not increasing with tuition.
    //             this.applyModals(this.data[i]);
    //         }

            
    //         this.data[i].new_total_tuition = this.sumColumns(tuition_columns, this.data[i]); // After all mods.
    //     }

    // }

    // randomSample(year) {
    //     if (this.rateOfGrowth <= 0) {
    //         return;
    //     }

    //     var secondYear = this.data.filter(function(d){return d.year == (year-1);}); // sample pool is the previous year.

    //     // sort by each category. 
    //     secondYear.sort(function(a, b) {
    //         return a["term"] - b["term"] || a["level"] - b["level"] || a["residencyType"] - b["residencyType"]  || a["studentType"] - b["studentType"];
    //     });

    //     // calculate the total number of samples needed.
    //     var samplesNeeded = Math.round((secondYear.length+1)*Math.pow(1+this.rateOfGrowth, year-1));
    //     samplesNeeded = samplesNeeded - secondYear.length+1;

    //     var portions = d3.nest()
    //         .key(function (d) { return d.term + " " + d.level + " " + d.residencyType + " " + d.studentType;})
    //         .rollup(function(v) { return Math.round(d3.sum(v, function (d) { return d.headcount; })/secondYear.length * samplesNeeded); })
    //         .entries(secondYear);
 
    //     // Sample 
    //     var sample = [];
    //     for (var i=0; i<secondYear.length; i++){
    //         for (var j=0; j<portions.length; j++){
    //             var keyString = secondYear[i].term + " " + secondYear[i].level + " " + secondYear[i].residencyType + " " + secondYear[i].studentType;
    //             var stringComp = keyString.localeCompare(portions[j].key);
    //             if (stringComp == 0 && portions[j].value > 0) {
                    
    //                 sample.push(secondYear[i]);
    //                 portions[j].value = portions[j].value - 1;
    //             }
    //         }
    //     }

    //     // Set the year
    //     var sampleNew = JSON.parse(JSON.stringify(sample));
    //     for (var i=0; i<sampleNew.length; i++){
    //         sampleNew[i].year = year;
    //     }

    //     // Add sample to data
    //     Array.prototype.push.apply(this.data, sampleNew); 
    // }

    // populateControls() {
    //     var element = document.getElementById("cutOffHours");
    //     element.value = this.cutOffHours;

    //     element = document.getElementById("cutOffHoursRate");
    //     element.value = this.cutOffHoursRate;

    //     element = document.getElementById("cutOffHoursLoss");
    //     element.value = this.cutOffHoursLoss;

    //     element = document.getElementById("tuitionIncrease");
    //     element.value = this.tuitionIncrease;

    //     element = document.getElementById("rateOfGrowth");
    //     element.value = this.rateOfGrowth;

    //     element = document.getElementById("noOnlineSurcharge");
    //     element.checked = this.noOnlineSurcharge;

    //     element = document.getElementById("noOnlinePrograms");
    //     element.checked = this.noOnlinePrograms;        
    // }

    // insertModals(newModals) {
    //     // remove any current modals.
    //     this.modals = newModals;
    // }

    // filterData() {
    //     // reset the data 
    //     this.data = JSON.parse(JSON.stringify(this.originalData));

    //     // generate the new years - this should be consistent with new data.
    //     this.generateYears();

    //     // loop through data and filters 
    //     var newData = [];
    //     //var data = JSON.parse(JSON.stringify(this.data));
    //     var data = this.data;
    //     var filters = this.filters;
    //     var numOfFilterVars = d3.nest().key(function(d) {return d.varName}).entries(filters).length;
    //     var matches = 0;
    //     if (filters.length > 0) {
    //         for(var i=0; i<data.length; i++) {
    //             for(var j=0; j<filters.length; j++) {
    //                 if (+data[i][filters[j].varName] === +filters[j].varValue) {
    //                     matches++;
    //                     if (matches === numOfFilterVars) {
    //                         newData.push(data[i]);
    //                         break;
    //                     }
    //                 }
    //             }
    //             matches = 0;
    //         }
    //         // Set data equal to the new filtered data.
    //         this.data = JSON.parse(JSON.stringify(newData));
    //     }
    //     // perform calculations on the new filtered data.
    //     this.performCalculations();        
    // }

}




/* Hour Threshold Tuition Rate to break even --- 0.470031509 */