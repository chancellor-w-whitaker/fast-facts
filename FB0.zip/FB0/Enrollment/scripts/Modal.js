/*
    Requires this html.
        <div class="modal fade" id="ModalLong" tabindex="-1" role="dialog" aria-labelledby="ModalLongTitle" aria-hidden="true">
            <div class="modal-dialog mw-100 w-50" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="ModalLongTitle">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body" id="modal_body">

                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-danger" id="ModalReset">Reset</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
            </div>
        </div>

      and these includes

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

*/

class ModalType {
    constructor() {
        this.modalTitleID = "ModalLongTitle";// the modal body - should be able to use this for them all.
        this.modalBodyID = "modal_body";     // the modal body - should be able to use this for them all.
        this.variable = [];
        this.variableDesc = null;
        this.modalValues = [];
        this.title = null;
    }
    // Push a y Variable column into the yVar array. 
    initializeModal(in_data, in_variable, variableDescArray, title) {
        //var yVar = { variable: in_variable, variable_desc: in_variable_desc };

        this.variable[0] = in_variable;
        this.variableDesc = variableDescArray;
        this.title = title;

        // get a distinct list of values for the variable in the data.
        // apparently this still returns strings. 
        var distinct = d3.map(in_data, function(d) {
            if (d[in_variable] == null)
                return null;
            return +d[in_variable];
        }).keys();

        // sort by each category. 
        distinct.sort(function(a, b) {
            return a - b;
        });

        for(var i=0; i<distinct.length; i++){
            var modalRecord;
            var comp = distinct[i].localeCompare("null");
            if (comp == 0)
                modalRecord = { code: null, value: 0};
            else
                modalRecord = { code: +distinct[i], value: 0};
            this.modalValues.push(modalRecord);
        }
    }

    populateModal() {
        // Set the modal name. This will alway us to determine the modal closing.
        var modalLong = $("#ModalLong");
        modalLong[0].setAttribute("name", this.variable[0]);

        // Set the title text.
        var title = $("#" + this.modalTitleID);
        title[0].textContent = this.title;

        // Set the name of the reset button.
        var resetModal = $("#ModalReset");
        resetModal[0].setAttribute("name", this.variable[0]);

        // Remove all child nodes
        // create a container-fluid
        // create a row.
        // create column1 and column2
        // move on.

        var mainContainer = document.createElement("div");
        mainContainer.setAttribute("class", "container-fluid");

        for (var i=0; i<this.modalValues.length; i++){
            var row = document.createElement("div");
            // don't display if null.
            if (this.modalValues[i].code == null) 
                row.setAttribute("class", "row d-none");
            else
                row.setAttribute("class", "row");

            var col1 = document.createElement("div");
            col1.setAttribute("class", "col-md-6 text-right align-middle");
            col1.innerHTML = this.variableDesc[this.modalValues[i].code];
            row.appendChild(col1);

            var col2 = document.createElement("div");
            col2.setAttribute("class", "col-md-6 pb-2");
            var input = document.createElement("input");
            input.setAttribute("type", "number");
            input.setAttribute("class", "form-control inputData");
            input.setAttribute("step", "1");
            input.setAttribute("value", this.modalValues[i].value);
            col2.appendChild(input);
            row.appendChild(col2);

            mainContainer.appendChild(row);

            //<input type="number" step="1" class="form-control" id="cutOffHours"></input>
        }

        // Get the modal body, remove all child nodes, then appended the new to it.
        var body = document.getElementById(this.modalBodyID);
        if (body.firstChild !== null) {
            while (body.firstChild) {
                body.removeChild(body.firstChild);
            }
        }
        body.appendChild(mainContainer);

    }

    saveModal (domElement) {
        //console.log(this.variable);
        //var test = domElement;
        var inputs = domElement.getElementsByClassName("inputData");

        // I am assuming this is in the same order as we populated.
        for(var i=0; i<inputs.length; i++) {
            this.modalValues[i].value = +inputs[i].value;
        }

        // loop through the inputs moving the values from input to this.modalValues.
    }

    resetModal (domElement) {
        //console.log(this.variable);
        //var test = domElement;
        var inputs = domElement.getElementsByClassName("inputData");

        // Loop through all inputs and reset to 0.
        for(var i=0; i<inputs.length; i++) {
            //this.modalValues[i].value = +0;
            inputs[i].value = 0;
        }

    }

    addVariableToModal(inVar) {
        // inVar is a string 
        this.variable.push(inVar);
    }

    getModalValue(inCode) {
        // takes a code an returns the value for it.
        for(var i=0; i<this.modalValues.length; i++) {
            if (inCode == this.modalValues[i].code)
                return this.modalValues[i].value;
        }
        return 0;
    }
}