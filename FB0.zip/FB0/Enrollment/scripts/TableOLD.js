/* 
This version of SummaryTable is only setup for 1 categorical column and the rest summary columns.
It also must reference a global SummaryTable object named tableChart.
*/

function SummaryTable(htmlObjID, numerator, denominator) {
    this.htmlObjID = "#" + htmlObjID;   /* This is the html object where the chart will live. */
    this.htmlChartID = htmlObjID + "_table";

    this.numerator = numerator;
    this.denominator = denominator;     // If blank then no percents will get calculated. 
    this.labelFormat = d3.format(',.0f');

    this.chartData = null;
    this.chartDataSum = null;
    this.rowGroups = [];     // list of columns in the order they are to be grouped. (term, program)
    this.summaryCol = null;  // single column (year, term, etc..)
    this.summaryColValues = null;
    this.columnOrder = null;



    this.headerPrevClick = null;
    this.headerClicks = 1;


    this.table = null;
    this.thead = null;
    this.tbody = null;
    this.rows = null;
    this.cells = null;
    this.bgColor = d3.scaleOrdinal().range(["#ffffff", "#E0E0E0", "#98abc5", "#8a89a6", "#7b6888", "#6b486b", "#a05d56", "#d0743c", "#ff8c00"]);
    this.fgColor = d3.scaleOrdinal().range(["#000000", "#000000", "#ffff00", "#FCFCFC", "#98abc5", "#98abc5", "#98abc5", "#98abc5", "#98abc5"]);
}

SummaryTable.prototype.sortTable = function (sortColumn) {
    // I don't really like this because it has to access the global tableChart variable. 
    // Sort the table by the column we clicked on.
    // if the column we clicked on is in summaryColValues then it is always a numeric sort.
    var tableChart2 = this;
    var inSummaryCols = false;
    for(var i=0; i<tableChart2.summaryColValues.length; i++) {
        if (tableChart2.summaryColValues[i] == sortColumn) {
            inSummaryCols = true;
            break;
        }
    }
    // 
    var column = sortColumn;
    //var thisColumn = this;
    // if what we currently clicked is what we previously clicked then increment on clicks.
    if (tableChart2.headerPrevClick == sortColumn)
        tableChart2.headerClicks++;
    else
        tableChart2.headerClicks=1;
    tableChart2.headerPrevClick = sortColumn;
    
    var tableData = d3.nest()
        .key(function (d) {
            return d[column];
        }).sortKeys(function(a, b) {
            if(inSummaryCols) {
                if (tableChart2.headerClicks % 2 == 1)
                    return d3.descending(+a, +b);
                else 
                    return d3.ascending(+a, +b);
            }
            else {
                if (tableChart2.headerClicks % 2 == 1) 
                    return d3.descending(a, b);
                else 
                    return d3.ascending(a, b);
            }
        })
        .entries(tableChart2.chartData);
    // flatten the data back out.
    var tableData2 = [];
    for (var i=0; i<tableData.length; i++){
        for (var j=0; j<tableData[i].values.length; j++)
            tableData2.push(tableData[i].values[j]);
    }
    // Redraw the table.
    tableChart2.chartData = tableData2;
    
}

SummaryTable.prototype.uniqueKeys = function (arr, column) {
    /*var unique = arr.map(function (d) { 
            return d[column]; 
        }).filter(function (e,i,a) {
            // e = value we are looking for.
            // i = index
            // a = the array we are pulling from.
            // I have a really hard time conceptionally figuring out how this changing works.
            return i === a.indexOf(e);
        });
    */

    // The code below was much faster than the code above. 
    var unique = d3.map(arr, function(d){return d[column];}).keys();
    return unique;
}

SummaryTable.prototype.rollUpData = function (inData) {
    // reset these when rollup happens so we don't end up with a sort icon on a column.
    //this.headerPrevClick = null;
    this.headerClicks = 1;

    var numerator = this.numerator;
    var denominator = this.denominator;
    var rowGroups = this.rowGroups;
    this.chartData = inData;
    var summaryCol = this.summaryCol;
    var summaryColValues = this.uniqueKeys(inData, summaryCol).sort();
    this.summaryColValues = summaryColValues;
    

    // If we want the total -- which equates to 1 row in our table we need to add that column.
    if (rowGroups == "Total") {
        for(var i=0; i<this.chartData.length; i++) {
            this.chartData[i].TotalRow = "Total";
        }
        this.rowGroups = ["TotalRow"];
        rowGroups = this.rowGroups;
    }
    this.columnOrder = this.rowGroups.concat(summaryColValues);


    // Compute the total. 
    // var total =   d3.sum(filteredData.filteredData, function (d) { return d[xNumerator]; }); 
    // Roll up with initial data by the codes in the dataset.
    var chartData2 = d3.nest()
    .key(function (d) { 
        //console.log("d");
        var string = "";
        for (var i = 0; i < rowGroups.length; i ++) {
            if (i==0)
                string = string + "" + rowGroups[i] + "=" + d[rowGroups[i]];
            else    
                string = string + "|:|" + rowGroups[i] + "=" + d[rowGroups[i]];
        }
        return string;
    }) 
    .key (function (d) {
        return d[summaryCol];
    })
    .rollup(function (v) { 
        if (numerator != null && denominator == null) {    
            return {
                numerator:  d3.sum(v, function (d) { 
                    var temp = d[numerator];
                    return d[numerator]; 
                })
            }; 
        }
        else {
            return {
                numerator:  d3.sum(v, function (d) { return d[numerator]; })/d3.sum(v, function (d) { return d[denominator]; })
            };
        }
    })
    .entries(this.chartData);

    var flat = [];
    for(var i = 0; i<chartData2.length; i++) {
        var object = {};

        for(var j = 0; j<summaryColValues.length; j++) {
            // create the properties for the object. 
            object[summaryColValues[j]] = 0;
        }

        var values = chartData2[i].values;
        for(var j = 0; j<values.length; j++) {
            // now loop through setting the values. 
            object[values[j].key] = values[j].value.numerator;
        }

        var keys = chartData2[i].key.split("|:|");
        for (var j = 0; j<keys.length; j++) {
            var keyValueCombo = keys[j].split("=");
            object[keyValueCombo[0]] = keyValueCombo[1];
        }

        flat.push(object);
    }

    this.chartData = flat;
    this.sortTable(this.rowGroups[0]);
}

// The table generation function
SummaryTable.prototype.tabulate = function () {
    if (this.table == null) {
        this.table = d3.select(this.htmlObjID).append("table");
        this.table.attr("id", this.htmlChartID);
        this.table.attr("class", "tableMain");
        //this.table.attr("style", "width: 100%; padding-top:5px;");
        //this.table.attr("style", "width: 900px");
        this.thead = this.table.append("thead");
        this.tbody = this.table.append("tbody");
    }
    
    var z = this.bgColor;
    var y = this.fgColor;
    var columns = this.columnOrder;
    var summaryColValues = this.summaryColValues;
    var chartData = this.chartData;
    var headerClicks = this.headerClicks;
    var headerPrevClick = this.headerPrevClick;

    this.thead.selectAll("tr")
        .remove()
        .exit()
        .data(columns);

    // append the header row
    //.attr("style", "background-color:#000; color:#FCFCFC; cursor: pointer; ")
    this.thead.append("tr")
        .selectAll("th")
        .data(columns)
        .enter()
        .append("th")
            .html(function(column) { 
                var columnHeader = column;

                if (summaryColValues.indexOf(columnHeader) < 0)
                    columnHeader = "Category";                
                return columnHeader;

                /*
                if (headerPrevClick != column)
                    return columnHeader;   
                else if (headerClicks % 2 == 1)
                    return columnHeader +  ' <i class="material-icons" style="font-size:18px">arrow_drop_down</i>';
                else if (headerClicks % 2 == 0)
                    return columnHeader +  ' <i class="material-icons" style="font-size:18px">arrow_drop_up</i>';                
                */
            })
            .attr("class", function (d) {
                if (headerPrevClick == d && headerClicks%2 == 1) 
                    return "tableHeader ascending";
                else if (headerPrevClick == d && headerClicks%2 == 0) 
                    return "tableHeader descending";
                return "tableHeader";
            })
            .style("text-align", function (column) {
                var style = "right";
                if (summaryColValues.indexOf(column) < 0)
                    style = "left";                
                return style;
            })
            .on("click", function (d) {
                //tableChart.headerPrevClick = d;
                tableChart.sortTable(d);
                tableChart.tabulate();
                // I don't really like this because it has to access the global tableChart variable. 
                // Sort the table by the column we clicked on.
                // if the column we clicked on is in summaryColValues then it is always a numeric sort.
                /*
                var inSummaryCols = false;
                for(var i=0; i<tableChart.summaryColValues.length; i++) {
                    if (tableChart.summaryColValues[i] == d) {
                        inSummaryCols = true;
                        break;
                    }
                }

                // 
                var column = d;
                var thisColumn = this;

                // if what we currently clicked is what we previously clicked then increment on clicks.
                if (tableChart.headerPrevClick == d)
                    tableChart.headerClicks++;
                else
                    tableChart.headerClicks=1;
                tableChart.headerPrevClick = d;

                
                var tableData = d3.nest()
                    .key(function (d) {
                        return d[column];
                    }).sortKeys(function(a, b) {
                        if(inSummaryCols) {
                            if (tableChart.headerClicks % 2 == 1)
                                return d3.descending(+a, +b);
                            else 
                                return d3.ascending(+a, +b);
                        }
                        else {
                            if (tableChart.headerClicks % 2 == 1) 
                                return d3.descending(a, b);
                            else 
                                return d3.ascending(a, b);
                        }
                    })
                    .entries(tableChart.chartData);

                // flatten the data back out.
                var tableData2 = [];
                for (var i=0; i<tableData.length; i++){
                    for (var j=0; j<tableData[i].values.length; j++)
                        tableData2.push(tableData[i].values[j]);
                }

                // Redraw the table.
                tableChart.chartData = tableData2;
                tableChart.tabulate();
                */
            });
    
    this.tbody.selectAll("tr")
        .remove()
        .exit()
        .data(this.chartData);

    // create a row for each object in the data
    this.rows = this.tbody.selectAll("tr")
        .data(this.chartData)
        .enter()
        .append("tr")
            .attr("class", function (d) {
                return "tableMainRow";
                //return "TableRow_Group_" + d.Group;
            })
            .attr("style", function (d, i) {
                // for alternating row colors.
                var mod_i = i % 2;
                return "background-color:" + z(mod_i) + "; color:" + y(mod_i) + ";"; 
            })
            .on("mouseover", function() {
                // highlight the row.
                var selected = d3.select(this);
                var string = "background-color:#FFEB3B; color:#000000;";
                selected.attr("style", string);
            })
            .on("mouseout", function(d, i) {
                // remove the highlight from the row.
                // I don't really like this because it has to access the global tableChart variable. 
                var selected = d3.select(this);
                var mod_i = i % 2;
                var string = "background-color:" + tableChart.bgColor(mod_i) + "; color:" + tableChart.fgColor(mod_i) + ";";
                selected.attr("style", string);
            });

    // create a cell in each row for each column
    var labelFormat = this.labelFormat;
    this.cells = this.rows.selectAll("td")
        .data(function(row) {
            var year = row.year;
            var value = row.value;
            var temp = columns.map(function(column) {
                
                    return {column: column, value: row[column]};

            });
            return temp;
        })
        .enter()
        .append("td")
        .attr("class", "summarytd")
        .attr("style", function(d) {
            for(var i=0; i<summaryColValues.length; i++)
                if (d.column == summaryColValues[i]) {
                    return "text-align:right";
                }
            return "text-align:left";
        }) 
        .html(function(d) { 
            if (summaryColValues.indexOf(d.column) >= 0) {
                //var commas = d3.format(',.0f');
                var value = labelFormat(d.value);
                return value; 
            }
            return d.value;
        });

        //this.sortTable("Category");

}

// Remove the table from the browser window.
SummaryTable.prototype.removeFromBrowser = function () {
     // Remove the table from the browser window.
     var htmlID = "#" + this.htmlChartID;
     $(htmlID).remove();
}