
function compareArrays(array1, array2) {
    // They do not have the same number of elements so immediately return false.
    // http://www.mattzeunert.com/2016/01/28/javascript-deep-equal.html
    if (array1.length != array2.length) 
        return false;

    var value1 = JSON.stringify(array1);
    var value2 = JSON.stringify(array2);
    if (value1 !== value2)
        return false;

    return true;
}

function copyObject(object1) {
    var cloned = JSON.parse(JSON.stringify(object1));
    return cloned;
}

function iframeLoaded() {
    alert("Iframe is now loaded.");
}

function enableDataLoading(toggle) {
    var dataLoading = document.getElementById("data_loading");
    if (toggle == true)
        dataLoading.className = "ui active dimmer";
    else
        dataLoading.className = "ui disabled dimmer";
}

function anyMissingDropDownChecks() {
    // dropdown classNames that contain red have all their checkboxes unchecked.
    var redDropDowns = document.getElementsByClassName('ui dropdown red');
    if (redDropDowns == null) 
        return 0; 
    return redDropDowns.length;
} 