const onlineProgram=[
'On-Campus Program',
'Online Program'
];
