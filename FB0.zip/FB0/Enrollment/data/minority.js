const minority=[
'Minority',
'Non-Minority'
];
