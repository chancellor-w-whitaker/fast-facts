const college=[
'Academic Affairs',
'College of Business & Tech',
'College of Education',
'College of Health Sciences',
'College of Justice & Safety',
'College of Ltrs, Arts, SocSci',
'College of Science',
'Graduate School'
];
