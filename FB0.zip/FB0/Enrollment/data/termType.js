const termType=[
'Fall',
'Spring',
'Summer'
];
