const race=[
'American Indian or Alaskan Native, Non-Hispanic Only',
'Asian, Non-Hispanic Only',
'Black, Non-Hispanic Only',
'Hispanic or Latino, regardless of race',
'Native Hawaiian or Other Pacific Islander, Non-Hispanic Only',
'Nonresident Alien',
'Race and Ethnicity Unknown',
'Two or More Races',
'White, Non-Hispanic Only'
];
