const inOutState=[
'In-State',
'International',
'Out-of-State'
];
