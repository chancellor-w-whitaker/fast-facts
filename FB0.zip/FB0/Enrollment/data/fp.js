const fp=[
'Full-time',
'Part-time'
];
