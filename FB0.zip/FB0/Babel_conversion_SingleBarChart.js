"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var SingleBarChart =
/*#__PURE__*/
function () {
  function SingleBarChart(htmlObjID, xVariable, yVariable, yFormat) {
    _classCallCheck(this, SingleBarChart);

    this.htmlObjID = "#" + htmlObjID;
    /* This is the html object where the chart will live. */

    this.htmlChartID = htmlObjID + "_singleBar";
    this.xVar = xVariable.toUpperCase();
    /* String - Categorical column in data */

    this.yVar = yVariable.toUpperCase();
    /* String - Numerical column in data */

    this.height = 200;
    this.width = 500;
    this.margins = {
      top: 20,
      right: 20,
      bottom: 30,
      left: 40
    };
    this.padding = 0.2;
    /* Space between the bars. */

    this.yDemScale = 0;
    /* y demininsonal scale - Decimal from 0 to 1. 0 shows scales from 0 to max value. */

    this.showXAxis = true;
    this.showYAxis = false;
    this.barColorRange = {
      start: "#D6D6D6",
      stop: "#4C151E"
    };
    this.barHoverColor = "#cc9900";
    this.format = yFormat;
    /* --- These properties should not be modified and are set in methods ---  */

    this.dataIsSet = false;
    this.mainData = null;
    this.chartData = null;
    this.svg = null;
    this.xScale = null;
    this.xAxis = null;
    this.yScale = null;
    this.yAxis = null;
  }

  _createClass(SingleBarChart, [{
    key: "rollUpData",
    value: function rollUpData() {
      /*If I'm going to change the x-axis label then I can't do this.*/
      //if (this.dataIsSet == true)
      //    return;
      var xVar = this.xVar;
      var yVar = this.yVar;
      this.chartData = d3.nest().key(function (d) {
        return d[xVar];
      }).rollup(function (v) {
        return d3.sum(v, function (d) {
          return d[yVar];
        });
      }).entries(this.mainData);
      this.dataIsSet = true; // Shorten the key name based on the size of the screen.
      // This can get a little complicated.
      // Boot strap sizes --- small 576, medium 768, large 992, x-large 1200

      var screen_size = $("body").width();
      var keyLength = this.chartData[0].key.length;

      /*if (768 <= screen_size && screen_size < 992 && keyLength == 9) {
        // Example -- Fall 2009
        for (var i = 0; i < this.chartData.length; i++) {
          this.chartData[i].key = (+this.chartData[i].key.substr(5, 4)).toString();
        }
      */
      if (768 <= screen_size && screen_size < 1200 && keyLength == 9) {
      // Example -- Fall 2009
        for (var i = 0; i < this.chartData.length; i++) {
          this.chartData[i].key = (+this.chartData[i].key.substr(5, 4)).toString();
        }
      } else if (0 <= screen_size && screen_size < 768 && keyLength == 9) {
        // Example -- Fall 2009
        for (var i = 0; i < this.chartData.length; i++) {
          this.chartData[i].key = (+this.chartData[i].key.substr(7, 2)).toString();
        }
      } else if (768 <= screen_size && screen_size < 992 && keyLength == 7) {
        // Example -- 2009-10
        for (var i = 0; i < this.chartData.length; i++) {
          this.chartData[i].key = (+this.chartData[i].key.substr(0, 4) + 1).toString();
        }
      } else if (0 <= screen_size && screen_size < 768 && keyLength == 7) {
        // Example -- 2009-10
        for (var i = 0; i < this.chartData.length; i++) {
          this.chartData[i].key = (+this.chartData[i].key.substr(0, 4) + 1).toString().substr(2, 2);
        }
      } else if (0 <= screen_size && screen_size < 768 && keyLength == 4) {
        // Example -- 2009
        for (var i = 0; i < this.chartData.length; i++) {
          this.chartData[i].key = this.chartData[i].key.substr(2, 2);
        }
      }
    }
  }, {
    key: "setData",
    value: function setData(dataset, subsetVar, subsetVal) {
      var subsetVar = subsetVar.toUpperCase();

      //this.chartData = dataset; // set the new dataset.
      this.dataIsSet = false; // set this to false so the object knows it needs summarized.

      var newData = [];

      for (var i = 0; i < dataset.length; i++) {
        if (dataset[i][subsetVar] === subsetVal) {
          newData.push(dataset[i]);
        }
      }

      this.mainData = newData; //this.chartData = newData;

      this.rollUpData(); // call the rollUpData function so it will do a rollup of the data.  
    }
  }, {
    key: "updateChart",
    value: function updateChart() {
      // 
      this.rollUpData(); // Determine format of numbers. 

      var nFormat = d3.format(this.format);
      var yFormat = d3.format(this.format);
      if (this.format === ".2%") yFormat = d3.format(".0%"); // Compute the margins. 

      var width_ = $(this.htmlObjID).width() - this.margins.left - this.margins.right;
      var height_ = this.height - this.margins.top - this.margins.bottom; // Set the x axis domain.
      // The range needs to be reset.   
      // create the x scale and only set the range.
      // If the width falls below a certain range, don't show the x axis.

      this.xScale = d3.scaleBand().range([0, width_]).padding(this.padding);
      var xScale = this.xScale;
      xScale.domain(this.chartData.map(function (d) {
        return d.key;
      }));
      this.xAxis = d3.axisBottom(this.xScale); // Select all xAxis, take them out, and exit the previous dataset. 

      this.svg.selectAll('.xAxis').remove().exit().data(this.chartData); // Append the new xAxis to the svg. 
      //if (width_ > 400) {

      this.svg.append('g').attr('class', 'xAxis').attr('transform', "translate(0," + height_ + ")").call(this.xAxis).selectAll('text').attr("style", "font-size: 9px;").style('text-anchor', 'middle').attr("dx", "0.0em") // controls the left and right movements of the xaxis values.
      .attr("dy", "1.25em"); // controls the up and down movements of the xaxis values.
      //}
      // Set the y axis domain.
      // The domain should be 20% below the range.
      // var minValue = d3.min(this.chartData, function (d) { return d.value; }) * .80;
      // if (minValue <= 20 && minValue > 1)
      //     minValue = 0;
      // var maxValue = d3.max(this.chartData, function (d) { return d.value; });
      // var yScale = this.yScale;
      // yScale.domain([minValue, maxValue]);
      // // recreate the y Axis since the y Scale has changed.
      // this.yAxis = d3.axisLeft(this.yScale);

      var minValue = d3.min(this.chartData, function (d) {
        return d.value;
      });
      var maxValue = d3.max(this.chartData, function (d) {
        return d.value;
      });
      var range = maxValue - minValue;
      var newMinValue = maxValue - range * 2;
      var yScale = this.yScale;
      yScale.domain([newMinValue, maxValue]);
      this.yAxis = d3.axisLeft(this.yScale);
      var formating = this.format;
      this.svg.selectAll('.yAxis').remove().exit().data(this.chartData); // append left axis.

      this.svg.append("g").attr('class', 'yAxis').call(this.yAxis.ticks(7).tickFormat(yFormat)); // Select all current bars, take them out, and exit the previous dataset.

      var bars = this.svg.selectAll('.bar').remove().exit().data(this.chartData); // Send the new information to the bars. 

      var originalData = this.mainData;
      bars.enter().append('rect').attr('class', 'bar').attr("fill", "#4C151E").attr('x', function (d) {
        return xScale(d.key);
      }).attr('y', function (d) {
        return height_;
      }).attr('data-toggle', 'tooltip').attr('data-placement', 'left').attr('title', function (d, i) {
        if (originalData[i].DESCR1.length == 0) return "<b>" + originalData[i].CALENDAR + "</b><br/>" + nFormat(d.value);else return "<b>" + originalData[i].CALENDAR + "</b><br/>" + originalData[i].DESCR1 + "<br/>" + nFormat(d.value);
      }).on("mouseover", function () {
        d3.select(this).attr("fill", "DodgerBlue");
      }).on("mouseout", function () {
        d3.select(this).attr("fill", function (d) {
          return d3.interpolateBuPu((d.value - newMinValue) / (maxValue - newMinValue));
        });
      })
      /*.transition() // apply a transition
      .ease(d3.easeCubic)
      .duration(1000)
      */
      .attr('x', function (d) {
        return xScale(d.key);
      }).attr('width', xScale.bandwidth()).attr('y', function (d) {
        return yScale(d.value);
      }).attr('height', function (d) {
        //console.log(height_ - yScale(d.value));
        return height_ - yScale(d.value);
      }).attr("fill", function (d) {
        return d3.interpolateBuPu((d.value - newMinValue) / (maxValue - newMinValue));
      })
      /*.on("end", function () {
          //enableDataLoading(false);
          var barLabelRates = document.getElementsByClassName("barLabelValue");
          for (var i = 0; i < barLabelRates.length; i++) {
              barLabelRates[i].style.fill = "#ffff66";
          }
      })*/
      ;
      var screen_size = $("body").width();

      if (screen_size >= 992) {
        // update the text labels for the bars.
        var updateLabels = this.svg.selectAll('.barLabelValue').remove().exit().data(this.chartData);
        updateLabels.attr('y', function (d) {//return height_;
          //return yScale(d.value)+15; 
        }).attr('height', function (d) {//return height_ - yScale(d.value)
          //return 0;
          //return height_;
        });
        updateLabels.enter().append('text').text(function (d) {
          //return "" + d3.format(",")(d.value);
          return "" + nFormat(d.value);
        }).attr('class', 'barLabelValue').attr("text-anchor", "middle").attr('x', function (d, i) {
          return xScale(d.key) + xScale.bandwidth() / 2;
        }).attr("y", function (d) {
          return yScale(d.value) + 15;
        }).attr("font-family", "sans-serif") //.attr("font-size", "12px")
        .attr("style", "font-size: 10px;").style('fill', 'white');
      } // This is required so Bootstrap tooltip will work on the bars.
      // html: true allows it to interpret html in the title attribute.
      // the css for the tooltip is in the index.html page.


      $(".bar").tooltip({
        'container': 'body',
        'placement': 'top',
        'html': true
      });
      $('.bar').tooltip('hide');
    }
  }, {
    key: "initialChart",
    value: function initialChart() {
      // if svg already exists then no need to recreated everything again.
      if (this.svg !== null) return; // Create the svg drawing area. 

      this.svg = d3.select(this.htmlObjID).append('svg').attr("id", this.htmlChartID) //.attr('width', this.width)
      .attr('width', '100%').attr('height', this.height) //.attr('height', '100%') // height has to be specified as pixels
      .append('g').attr('transform', "translate(" + this.margins.left + "," + this.margins.top + ")"); // Compute the margins. 

      var width_ = $(this.htmlObjID).width() - this.margins.left - this.margins.right;
      var height_ = this.height - this.margins.top - this.margins.bottom; // create the x scale and only set the range.

      this.xScale = d3.scaleBand().range([0, width_]).padding(this.padding); // create the y scale and only set the range.

      this.yScale = d3.scaleLinear().range([height_, 0]);
    }
  }, {
    key: "drawChart",
    value: function drawChart(dataset, subsetVar, subsetVal) {
      // call and set the new dataset.
      this.setData(dataset, subsetVar, subsetVal); // Create the chart objects. Note, this will not recreate them when they are already created.

      if(this.svg == null) {
        this.initialChart(); // This should put the data on the screen.
      }

      this.updateChart();
    }
  }]);

  return SingleBarChart;
}();