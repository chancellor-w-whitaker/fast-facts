/*
Adjustments can be made to any of these methods outside of this file.
This is just the standard default operation of a single column bar chart.

https://bl.ocks.org/syncopika/f1c9036b0deb058454f825238a95b6be
This webpage was vital in helping me update and existing svg.

Width is not even defined on the multiline file.

#5E213B = EKU Maroon
*/
class SingleBarChart {
    constructor(htmlObjID, xVariable, yVariable, yFormat) {
        this.htmlObjID = "#" + htmlObjID; /* This is the html object where the chart will live. */
        this.htmlChartID = htmlObjID + "_singleBar";
        this.xVar = xVariable.toUpperCase(); /* String - Categorical column in data */
        this.yVar = yVariable.toUpperCase(); /* String - Numerical column in data */
        this.height = 200;
        this.width = 500;
        this.margins = { top: 20, right: 20, bottom: 30, left: 40 };
        this.padding = 0.2; /* Space between the bars. */
        this.yDemScale = 0; /* y demininsonal scale - Decimal from 0 to 1. 0 shows scales from 0 to max value. */
        this.showXAxis = true;
        this.showYAxis = false;
        this.barColorRange = { start: "#c2c2f0", stop: "#3333cc" };
        this.barHoverColor = "#cc9900";
        this.format = yFormat;

        /* --- These properties should not be modified and are set in methods ---  */
        this.dataIsSet = false;
        this.mainData = null;
        this.chartData = null;
        this.svg = null;
        this.xScale = null;
        this.xAxis = null;
        this.yScale = null;
        this.yAxis = null;
    }

    rollUpData() {
        /*If I'm going to change the x-axis label then I can't do this.*/
        //if (this.dataIsSet == true)
        //    return;

        var xVar = this.xVar.toUpperCase();
        var yVar = this.yVar.toUpperCase();
        this.chartData = d3.nest()
            .key(function (d) { return d[xVar]; })
            .rollup(function (v) {
                return d3.sum(v, function (d) { return +d[yVar]; });
            })
            .entries(this.mainData);
        this.dataIsSet = true;
        if(this.chartData.length == 0)
            this.chartData = [{
            "key" : "NO DATA",
            "values" : [[]]
            }]; 

        // Shorten the key name based on the size of the screen.
        // This can get a little complicated.
        // Boot strap sizes --- small 576, medium 768, large 992, x-large 1200
        var screen_size = $("body").width();
        var keyLength = this.chartData[0].key.length;
        if (768 <= screen_size && screen_size < 992 && keyLength == 9) {
            // Example -- Fall 2009
            for (var i =0; i<this.chartData.length; i++) {
                this.chartData[i].key = (+this.chartData[i].key.substr(5, 4)).toString();
            }
        }
        else if (0 <= screen_size && screen_size < 768 && keyLength == 9) {
            // Example -- Fall 2009
            for (var i =0; i<this.chartData.length; i++) {
                this.chartData[i].key = (+this.chartData[i].key.substr(7, 2)).toString();
            }
        }
        else if (768 <= screen_size && screen_size < 992 && keyLength == 7) {
            // Example -- 2009-10
            for (var i =0; i<this.chartData.length; i++) {
                this.chartData[i].key = (+this.chartData[i].key.substr(0, 4) + 1).toString();
            }
        } else if (0 <= screen_size && screen_size < 768 && keyLength == 7) {
            // Example -- 2009-10
            for (var i =0; i<this.chartData.length; i++) {
                this.chartData[i].key = (+this.chartData[i].key.substr(0, 4) + 1).toString().substr(2,2);
            }
        } else if (0 <= screen_size && screen_size < 768 && keyLength == 4) {
            // Example -- 2009
            for (var i =0; i<this.chartData.length; i++) {
                this.chartData[i].key = this.chartData[i].key.substr(2, 2);
            }
        }
    }

    setData(dataset, subsetVar, subsetVal) {
        //this.chartData = dataset; // set the new dataset.
        this.dataIsSet = false; // set this to false so the object knows it needs summarized.

        var newData = [];
        for (var i=0; i<dataset.length; i++) {
            if(dataset[i][subsetVar] === subsetVal) {
                newData.push(dataset[i]);
            }
        }
        this.mainData = newData;
        //this.chartData = newData;

        this.rollUpData(); // call the rollUpData function so it will do a rollup of the data.  
    }

    updateChart() {
        // 
        this.rollUpData();

        if (this.chartData.length == 0) {

        }

        // Determine format of numbers. 
        var nFormat = d3.format(this.format);
        var yFormat = d3.format(this.format);
        if (this.format === ".2%")
            yFormat = d3.format(".0%");

        // Compute the margins. 
        var width_ = $(this.htmlObjID).width() - this.margins.left - this.margins.right;
        var height_ = this.height - this.margins.top - this.margins.bottom;


        // Set the x axis domain.
        // The range needs to be reset.   
        // create the x scale and only set the range.
        // If the width falls below a certain range, don't show the x axis.
        this.xScale = d3.scaleBand()
            .range([0, width_])
            .padding(this.padding);
        var xScale = this.xScale;
        xScale.domain(this.chartData.map(function (d) { return d.key; }));
        this.xAxis = d3.axisBottom(this.xScale);


        // Select all xAxis, take them out, and exit the previous dataset. 
        this.svg.selectAll('.xAxis')
            .remove()
            .exit()
            .data(this.chartData);

        // Append the new xAxis to the svg. 
        //if (width_ > 400) {
            this.svg.append('g')
                .attr('class', 'xAxis')
                .attr('transform', "translate(0," + height_ + ")")
                .call(this.xAxis)
                .selectAll('text')
                .attr("style", "font-size: 10px;")
                .style('text-anchor', 'middle')
                .attr("dx", "0.0em") // controls the left and right movements of the xaxis values.
                .attr("dy", "1.25em"); // controls the up and down movements of the xaxis values.
        //}

        // Set the y axis domain.
        // The domain should be 20% below the range.
        // var minValue = d3.min(this.chartData, function (d) { return d.value; }) * .80;
        // if (minValue <= 20 && minValue > 1)
        //     minValue = 0;
        // var maxValue = d3.max(this.chartData, function (d) { return d.value; });
        // var yScale = this.yScale;
        // yScale.domain([minValue, maxValue]);
        // // recreate the y Axis since the y Scale has changed.
        // this.yAxis = d3.axisLeft(this.yScale);
        var minValue = d3.min(this.chartData, function (d) { return d.value; });
        var maxValue = d3.max(this.chartData, function (d) { return d.value; });
        var range = maxValue - minValue;
        var newMinValue = maxValue - (range * 2);
        var yScale = this.yScale;
        yScale.domain([newMinValue, maxValue]);
        this.yAxis = d3.axisLeft(this.yScale);
        


        var formating = this.format;
       
        this.svg.selectAll('.yAxis')
            .remove()
            .exit()
            .data(this.chartData);
        // append left axis.
        this.svg.append("g")
            .attr('class', 'yAxis')
            .call(this.yAxis.ticks(7).tickFormat(yFormat));
      

        // Select all current bars, take them out, and exit the previous dataset.
        var bars = this.svg.selectAll('.bar')
            .remove()
            .exit()
            .data(this.chartData);

        // Send the new information to the bars. 
        
        var originalData = this.mainData;
        bars.enter()
            .append('rect')
            .attr('class', 'bar')
            .attr("fill", "#5E213B")
            .attr('x', function (d) {
                return xScale(d.key);
            })
            .attr('y', function (d) {
                return height_;
            })
            .attr('data-toggle', 'tooltip')
            .attr('data-placement', 'left')
            .attr('title', function (d, i) {
                // if (originalData.length > 0)
                    if (originalData[i].DESCR1.length == 0)
                        return "<b>" + originalData[i].CALENDAR + "</b><br/>" + nFormat(d.value);
                    else 
                        return "<b>" + originalData[i].CALENDAR + "</b><br/>" + originalData[i].DESCR1 + "<br/>"
                            + nFormat(d.value);
            })
            .on("mouseover", function () {
                var obj = this;
                // setTimeout(()=> {
                //     d3.select(obj)
                //         .attr("fill", "DodgerBlue");
                // }, 1000);
                d3.select(obj)
                        .attr("fill", "DodgerBlue");
            })
            .on("mouseout", function () {
                d3.select(this)
            	    .attr("fill",  function (d) {
                        return d3.interpolateBuPu((d.value-newMinValue)/(maxValue - newMinValue));
                    });
            })
            /*.transition() // apply a transition
            .ease(d3.easeCubic)
            .duration(1000)
            */
            .attr('x', function (d) {
                return xScale(d.key);
            })
            .attr('width', xScale.bandwidth())
            .attr('y', function (d) {
                return yScale(d.value);
            })
            .attr('height', function (d) {
                //console.log(height_ - yScale(d.value));
                return height_ - yScale(d.value);
            })
            .attr("fill", function (d) {
                return d3.interpolateBuPu((d.value-newMinValue)/(maxValue - newMinValue));

            })
            /*.on("end", function () {
                //enableDataLoading(false);
                var barLabelRates = document.getElementsByClassName("barLabelValue");
                for (var i = 0; i < barLabelRates.length; i++) {
                    barLabelRates[i].style.fill = "#ffff66";
                }
            })*/
            ;

        var screen_size = $("body").width();
        if (screen_size >= 992) {
            // update the text labels for the bars.
            var updateLabels = this.svg.selectAll('.barLabelValue')
            .remove()
            .exit()
            .data(this.chartData);

        

            updateLabels
                .attr('y', function (d) {
                    //return height_;
                    //return yScale(d.value)+15; 
                })
                .attr('height', function (d) {
                    //return height_ - yScale(d.value)
                    //return 0;
                    //return height_;
                });

            updateLabels
                .enter()
                .append('text')
                .text(function (d) {
                    //return "" + d3.format(",")(d.value);
                    return "" + nFormat(d.value);
                })
                .attr('class', 'barLabelValue')
                .attr("text-anchor", "middle")
                .attr('x', function (d, i) {
                    return xScale(d.key) + xScale.bandwidth() / 2;
                })
                .attr("y", function (d) { return yScale(d.value) + 15; })
                .attr("font-family", "sans-serif")
                //.attr("font-size", "12px")
                .attr("style", "font-size: 10px;")
                .style('fill', 'white');
        }

        // This is required so Bootstrap tooltip will work on the bars.
        // html: true allows it to interpret html in the title attribute.
        // the css for the tooltip is in the index.html page.
        $(".bar").tooltip({
            'container': 'body',
            'placement': 'top',
            'html': true
        });
    }

    initialChart() {
        // if svg already exists then no need to recreated everything again.
        if (this.svg !== null)
            return;

        // Create the svg drawing area. 
        this.svg = d3.select(this.htmlObjID)
            .append('svg')
            .attr("id", this.htmlChartID)
            //.attr('width', this.width)
            .attr('width', '100%')
            .attr('height', this.height)
            //.attr('height', '100%') // height has to be specified as pixels
            .append('g')
            .attr('transform', "translate(" + this.margins.left + "," + this.margins.top + ")");

        // Compute the margins. 
        var width_ = $(this.htmlObjID).width() - this.margins.left - this.margins.right;
        var height_ = this.height - this.margins.top - this.margins.bottom;


        // create the x scale and only set the range.
        this.xScale = d3.scaleBand()
            .range([0, width_])
            .padding(this.padding);
        // create the y scale and only set the range.
        this.yScale = d3.scaleLinear()
            .range([height_, 0]);
    }

    drawChart(dataset, subsetVar, subsetVal) {
        

        // call and set the new dataset.
        this.setData(dataset, subsetVar.toUpperCase(), subsetVal);
        // Create the chart objects. Note, this will not recreate them when they are already created.
        this.initialChart();
        // This should put the data on the screen.
        this.updateChart();
    }
}





